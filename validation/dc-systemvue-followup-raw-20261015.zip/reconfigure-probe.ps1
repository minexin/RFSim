param([Parameter(Mandatory=$true)][string]$ExpectedWorkspace,[Parameter(Mandatory=$true)][ValidateSet('linear-control','cubic-current','cubic-charge')][string]$Mode)
$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($s in @('-prepared.wsv','-prepared.json')){if(Test-Path -LiteralPath "$root/$Mode$s"){throw 'Evidence exists'}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class DCConfigure {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 static object Set(GENESYS.IItem part,string name,string text){var ps=part.GetItemByName("ParamSet");try{var p=ps.GetItemByName(name);try{Call(p,"Set",text);return Call(p,"GetValue");}finally{Marshal.ReleaseComObject(p);}}finally{Marshal.ReleaseComObject(ps);}}
 public static object Run(string path,string expected,string mode){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!=expected||!Convert.ToBoolean(Call(w,"IsAnalysisDone")))throw new Exception("Unexpected or active session");
    string before=root.ToXML(),errorsBefore=m.GetErrors();File.WriteAllText(path+"/"+mode+"-errors-before.txt",errorsBefore);Call(w,"ClearErrorLog");
    var ops=new List<object>();string failure=null;
    try{var designs=root.GetItemByName("Designs");try{var design=designs.GetItemByName("DC_Divider");try{var parts=design.GetItemByName("PartList");try{
     var load=parts.GetItemByName("RL");try{
      Call(load,"DeleteParams");Call(load,"ChangeModel",mode=="cubic-current"?"NLRES":"RES");
      if(mode=="cubic-current"){
       Set(load,"TYPE","2");Set(load,"MODELTYPE","0");ops.Add(new{name="RL.C",value=Set(load,"C","[1;0.001;0;0.002]"),xml=load.ToXML()});
      }else ops.Add(new{name="RL.R",value=Set(load,"R","2000"),xml=load.ToXML()});
     }finally{Marshal.ReleaseComObject(load);}
     var source=parts.GetItemByName("Vs");try{ops.Add(new{name="Vs.VDC",value=Set(source,"VDC",mode=="linear-control"?"3":"2"),xml=source.ToXML()});}finally{Marshal.ReleaseComObject(source);}
     if(mode=="cubic-charge"){
      parts.FromXML("<Item XName=\"PartList\" Type=\"PartList\"><Item XName=\"ChargeProbe\" Type=\"Part\"><Model>NLCAP</Model><Netlist>Port_1,1|Port_2,0</Netlist><MathLang><T>Bool</T><D>1</D></MathLang><Item XName=\"ParamSet\" Type=\"ParamSet\"/></Item></Item>");
      var charge=parts.GetItemByName("ChargeProbe");try{Call(charge,"ChangeModel","NLCAP");Set(charge,"TYPE","2");ops.Add(new{name="ChargeProbe.C",value=Set(charge,"C","[1;1e-9;0;3e-9]"),xml=charge.ToXML()});}finally{Marshal.ReleaseComObject(charge);}
     }
    }finally{Marshal.ReleaseComObject(parts);}}finally{Marshal.ReleaseComObject(design);}}finally{Marshal.ReleaseComObject(designs);}}catch(Exception e){failure=e.ToString();}
    string xml=root.ToXML();w.SaveAs(path+"/"+mode+"-prepared.wsv");
    return new{utc=DateTime.UtcNow.ToString("o"),workspace=root.GetName(),analysis_requested=false,errors_before=errorsBefore,errors=m.GetErrors(),failure=failure,operations=ops,input_xml=before,xml=xml};
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[DCConfigure]::Run($root,$ExpectedWorkspace,$Mode)
[IO.File]::WriteAllText("$root/$Mode-prepared.json",($record|ConvertTo-Json -Depth 20),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;failure=$record.failure;errors=$record.errors;operations=@($record.operations|Select-Object name,value)}|ConvertTo-Json -Depth 8
