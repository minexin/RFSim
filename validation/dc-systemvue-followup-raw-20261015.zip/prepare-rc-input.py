import copy, hashlib, json, math, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

root=Path(__file__).parent
source_path=Path('D:/project/RFModel/build-reference/RFModel_AttenuatorNoise.wsv')
original=ET.fromstring(source_path.read_bytes())
out=ET.Element('Item',{'XName':'Designs','Type':'Folder'})
design=ET.SubElement(out,'Item',{'XName':'RC_Physical','Type':'Design'})
def field(parent,name,value,kind=None):
    n=ET.SubElement(parent,name)
    if kind:
        ET.SubElement(n,'T').text=kind
        ET.SubElement(n,'D').text=str(value)
    else:n.text=str(value)
    return n
def item(parent,name,kind):return ET.SubElement(parent,'Item',{'XName':name,'Type':kind})
field(design,'Intent',1,'Int')
parts=item(design,'PartList','PartList')
source=copy.deepcopy(original.find('.//Item[@XName="Source"][@Type="Part"]'))
source.find('Netlist').text='1,1'
for n in list(source):
    if n.tag=='Item' and n.attrib.get('XName') not in ('ParamSet',):source.remove(n)
    elif n.tag not in ('Model','Netlist','MathLang','Item'):source.remove(n)
parts.append(source)
for name,model,net in [('C1','CAP','Port_1,1|Port_2,0'),('R12','RES','Port_1,1|Port_2,2'),
                       ('C12','CAP','Port_1,1|Port_2,2'),('R2','RES','Port_1,2|Port_2,0'),
                       ('C2','CAP','Port_1,2|Port_2,0')]:
    p=item(parts,name,'Part');field(p,'Model',model);field(p,'Netlist',net);field(p,'MathLang',1,'Bool');item(p,'ParamSet','ParamSet')
analysis=copy.deepcopy(original.find('.//Item[@Type="System Analysis"]'))
analysis.attrib['XName']='RCSystem';analysis.attrib['UserName']='RCSystem'
for n in list(analysis):
    if n.tag=='Item' and n.attrib.get('Type')=='PathData':analysis.remove(n)
for n in ('AutoRecalc','NeedRun','CalcHarmonics','CalcIntermods','CalcNoise','CalcPhaseNoise','ShowNoise','ShowPhaseNoise','ShowTotalNoise','ShowIntermods','AnalNoise','AnalRandNoise'):
    old=analysis.find(n)
    if old is not None:analysis.remove(old)
    field(analysis,n,0,'Bool')
for n in ('ShowSignals','ShowTotals','ShowComponents'):
    old=analysis.find(n)
    if old is not None:analysis.remove(old)
    field(analysis,n,1,'Bool')
def set_param(name,value,typed=None):
    p=analysis.find(f'Item[@XName="{name}"]')
    if p is None:p=item(analysis,name,'Param')
    for c in list(p):
        if c.tag in ('Data','DataEntry'):p.remove(c)
    field(p,'Data' if typed else 'DataEntry',value,typed)
for n,v in [('DesignName','RC_Physical'),('DataName','RCSystem_Data'),('Temperature','16.85'),('NominalZ0','50'),('MaxOrder','1')]:set_param(n,v)
for n,v in [('UseSpecReduction',0),('UsePrevSolution',0),('UseCarrierRange',0),('UseVolterra',0)]:set_param(n,v,'Int')
set_param('DataParts','1;6;Source;C1;R12;C12;R2;C2','Array_BString')
out.append(analysis)
xml=ET.tostring(out,encoding='utf-8',xml_declaration=True)
with (root/'rc-physical-entry.xml').open('xb') as f:f.write(xml)
baseline=json.loads(Path('D:/project/RFModel/validation/dc-bias-systemvue-readiness-20261015.json').read_text())
case=baseline['comparison_case_contract']['cases'][2]
plan={'created_utc':datetime.now(timezone.utc).isoformat(),'classification':'pre_acquisition_RC_physical_voltage_plan',
      'source_template_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),
      'input_xml_sha256':hashlib.sha256(xml).hexdigest(),
      'scope':'Two-node nonproportional RC at 1 kHz and 1 MHz. Cubic DC model creation failed separately and is not replaced by this linear case.',
      'Rs_ohm':1000,'source_available_power_watt_per_tone':0.00025,
      'source_available_power_dbm_per_tone':10*math.log10(0.25),'Vs_rms_volt_per_tone':1,
      'physical_Rs_location':'MultiSource internal source impedance R=1000; no separate source shunt and no output port termination',
      'physical_parts':{'C1_farad':1e-9,'R12_ohm':500,'C12_farad':4e-9,'R2_ohm':1/.003,'C2_farad':2e-9},
      'reference_contract':case,'native_criterion':'abs(actual-expected) <= 2e-12*max(1,abs(actual),abs(expected)); unchanged frozen_small_signal_test near()',
      'voltage_conversion':'positive-frequency peak complex voltage / sqrt(2) -> RMS; preserve raw spectra and node/direction identities',
      'current_classification':'Use raw vendor current if present. V/Z may be evaluated only with identified impedance/direction; source current derived from raw V and documented source impedance must be labelled derived, not a direct current export.',
      'prohibited':'No S-derived voltage/current and no fitting amplitudes or tolerances.'}
with (root/'rc-physical-plan.json').open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2)
print(json.dumps({k:plan[k] for k in ('created_utc','input_xml_sha256','Rs_ohm','source_available_power_dbm_per_tone','Vs_rms_volt_per_tone')},indent=2))
