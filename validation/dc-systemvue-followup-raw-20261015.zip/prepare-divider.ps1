$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($n in @('divider-prepare-before.wsv','divider-prepared.wsv','divider-prepared.json')) {if(Test-Path -LiteralPath "$root/$n"){throw "Refuse to overwrite $n"}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;
public static class DividerPrepare {
 static object Call(object o,string name,params object[] args){return o.GetType().InvokeMember(name,BindingFlags.InvokeMethod,null,o,args);}
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);
   vars[item.GetVarName(i)]=v is ValueType||v is string||v is Array||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){
   var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}
  }
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 static void Phase(string path,string text){File.AppendAllText(path+"/divider-prepare-phases.log",DateTime.UtcNow.ToString("o")+" "+text+Environment.NewLine);Console.Error.WriteLine(text);}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{
   var app=(GENESYS.Application)active;var m=app.Manager;
   try{
    if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");
    var w=m.GetWorkspaceByIndex(0);
    try{
     var item=(GENESYS.IItem)w;
     if(item.GetName()!="model-metadata-loaded")throw new Exception("Unexpected session; no edits submitted");
     if(!Convert.ToBoolean(Call(w,"IsAnalysisDone")))throw new Exception("Analysis running");
     w.SaveAs(path+"/divider-prepare-before.wsv");
     string errorsBefore=m.GetErrors();
     File.WriteAllText(path+"/divider-prepare-errors-before.txt",errorsBefore);
     Call(w,"ClearErrorLog");
     string failure=null;
     var operations=new List<object>();
     try{
      var designs=item.GetItemByName("Designs");
      try{
       var design=designs.GetItemByName("DC_Divider");
       try{
        var parts=design.GetItemByName("PartList");
        try{
         parts.FromXML(File.ReadAllText(path+"/voltage-probe-entry.xml"));
         string[] names={"Vs","Rs","Sense","RL","Vprobe"};
         string[] models={"VDC","RES","IPROBE","RES","TEST_POINT"};
         string[] parameters={"VDC","R","","R",""};
         string[] values={"3","1000","","2000",""};
         for(int i=0;i<names.Length;i++){
          Phase(path,"initialize-"+names[i]+"-"+models[i]);
          var part=parts.GetItemByName(names[i]);
          try{
           Call(part,"ChangeModel",models[i]);
           object parsed=null;
           if(parameters[i]!=""){
            var ps=part.GetItemByName("ParamSet");
            try{var p=ps.GetItemByName(parameters[i]);try{Call(p,"Set",values[i]);parsed=Call(p,"GetValue");}finally{Marshal.ReleaseComObject(p);}}
            finally{Marshal.ReleaseComObject(ps);}
           }
           operations.Add(new{name=names[i],model=models[i],parameter=parameters[i],expression=values[i],parsed=parsed,xml=part.ToXML()});
          }finally{Marshal.ReleaseComObject(part);}
         }
        }finally{Marshal.ReleaseComObject(parts);}
       }finally{Marshal.ReleaseComObject(design);}
      }finally{Marshal.ReleaseComObject(designs);}
     }catch(Exception e){failure=e.ToString();}
     Phase(path,"capture-readback-no-analysis-requested");
     string errors=m.GetErrors();var tree=Read(item,8);string xml=item.ToXML();
     w.SaveAs(path+"/divider-prepared.wsv");
     return new{utc=DateTime.UtcNow.ToString("o"),analysis_requested=false,workspace=item.GetName(),failure=failure,errors_before=errorsBefore,errors=errors,operations=operations,xml=xml,tree=tree};
    }finally{Marshal.ReleaseComObject(w);}
   }finally{Marshal.ReleaseComObject(m);}
  }finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[DividerPrepare]::Run($root)
[IO.File]::WriteAllText("$root/divider-prepared.json",($record|ConvertTo-Json -Depth 40),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;failure=$record.failure;errors=$record.errors;operations=@($record.operations|Select-Object name,model,parameter,expression,parsed);analysis_requested=$record.analysis_requested}|ConvertTo-Json -Depth 8
