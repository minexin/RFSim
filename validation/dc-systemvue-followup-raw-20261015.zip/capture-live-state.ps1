param([Parameter(Mandatory=$true)][string]$OutputStem)
$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
if($OutputStem -notmatch '^[a-z0-9-]+$'){throw 'Invalid evidence name'}
if(Test-Path -LiteralPath "$root/$OutputStem.json"){throw 'Output exists'}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
public static class DCReadOnly {
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);var a=v as Array;
   if(a!=null){var flat=new List<object>();foreach(var e in a)flat.Add(e);var dims=new List<int>();for(int j=0;j<a.Rank;j++)dims.Add(a.GetLength(j));vars[item.GetVarName(i)]=new{dimensions=dims,values=flat};}
   else vars[item.GetVarName(i)]=v is ValueType||v is string||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){
   var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}
  }
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 public static object Run(){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{
   var app=(GENESYS.Application)active;var m=app.Manager;
   try{
    if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");
    var w=m.GetWorkspaceByIndex(0);
    try{
     var item=(GENESYS.IItem)w;
     var done=w.GetType().InvokeMember("IsAnalysisDone",BindingFlags.InvokeMethod,null,w,new object[0]);
     return new{utc=DateTime.UtcNow.ToString("o"),analysis_requested=false,analysis_done=done,workspace=item.GetName(),errors=m.GetErrors(),xml=item.ToXML(),tree=Read(item,12)};
    }finally{Marshal.ReleaseComObject(w);}
   }finally{Marshal.ReleaseComObject(m);}
  }finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[DCReadOnly]::Run()
[IO.File]::WriteAllText("$root/$OutputStem.json",($record|ConvertTo-Json -Depth 60),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;errors=$record.errors;analysis_done=$record.analysis_done;children=@($record.tree.children|Select-Object -ExpandProperty name)}|ConvertTo-Json
