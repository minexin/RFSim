$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($s in @('session-before-restore.wsv','session-restored-after.wsv','session-restoration.json')){if(Test-Path -LiteralPath "$root/$s"){throw 'Evidence exists'}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class DCRestoreSession {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!="rc-hierarchy-physical-result"||!Convert.ToBoolean(Call(w,"IsAnalysisDone"))||m.GetErrors()!="")throw new Exception("Unexpected or active session");
    string before=root.ToXML();w.SaveAs(path+"/session-before-restore.wsv");
    string original=File.ReadAllText(path+"/session-preserved-before.wsv");
    // All task results are saved. Restore only this task-owned workspace from its immutable original snapshot.
    w.DeleteAllInternal();root.FromXML(original);Call(w,"ClearErrorLog");
    string restored=root.ToXML();w.SaveAs(path+"/session-restored-after.wsv");
    return new{utc=DateTime.UtcNow.ToString("o"),workspace=root.GetName(),workspace_count=m.GetWorkspaceCount(),analysis_requested=false,analysis_done=Call(w,"IsAnalysisDone"),errors=m.GetErrors(),before_xml=before,restored_xml=restored};
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[DCRestoreSession]::Run($root)
[IO.File]::WriteAllText("$root/session-restoration.json",($record|ConvertTo-Json -Depth 15),([Text.UTF8Encoding]::new($false)))
$record|Select-Object utc,workspace,workspace_count,analysis_requested,analysis_done,errors|ConvertTo-Json
