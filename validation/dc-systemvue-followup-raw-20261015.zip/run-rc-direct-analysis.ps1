param([Parameter(Mandatory=$true)][string]$ExpectedWorkspace,[Parameter(Mandatory=$true)][string]$OutputStem,[string]$AnalysisName='RCSystem')
$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
if($OutputStem -notmatch '^[a-z0-9-]+$'){throw 'Invalid evidence name'}
foreach($suffix in @('.json','-input.wsv','-result.wsv','-phases.log')) {if(Test-Path -LiteralPath "$root/$OutputStem$suffix"){throw 'Output exists'}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class RCDirectRun {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);var a=v as Array;
   if(a!=null){var flat=new List<object>();foreach(var e in a)flat.Add(e);var dims=new List<int>();for(int j=0;j<a.Rank;j++)dims.Add(a.GetLength(j));vars[item.GetVarName(i)]=new{dimensions=dims,values=flat};}
   else vars[item.GetVarName(i)]=v is ValueType||v is string||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}}
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 static void Phase(string path,string stem,string text){File.AppendAllText(path+"/"+stem+"-phases.log",DateTime.UtcNow.ToString("o")+" "+text+Environment.NewLine);Console.Error.WriteLine(text);}
 public static object Run(string path,string expected,string stem,string analysisName){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!=expected||!Convert.ToBoolean(Call(w,"IsAnalysisDone"))||m.GetErrors()!="")throw new Exception("Unexpected or non-idle/error-free session");
    var designs=root.GetItemByName("Designs");try{var analysis=designs.GetItemByName(analysisName);try{
     string dataset=stem.Replace('-','_')+"_Data";Call(analysis,"SetDataName",dataset);
     w.SaveAs(path+"/"+stem+"-input.wsv");string input=root.ToXML();
     string started=DateTime.UtcNow.ToString("o"),returned=null,failure=null;
     Phase(path,stem,"submit-one-native-COM-RunAnalysis");
     try{Call(analysis,"ClearModelCache");Call(analysis,"RunAnalysis");returned=DateTime.UtcNow.ToString("o");}catch(Exception e){failure=e.ToString();}
     Phase(path,stem,"read-existing-result-without-resubmission");
     object done=Call(w,"IsAnalysisDone");string errors=m.GetErrors();var tree=Read(root,12);string xml=root.ToXML();
     w.SaveAs(path+"/"+stem+"-result.wsv");
     return new{started_utc=started,returned_utc=returned,captured_utc=DateTime.UtcNow.ToString("o"),analysis_requested=true,analysis_done=done,workspace=root.GetName(),dataset=dataset,failure=failure,errors=errors,input_xml=input,xml=xml,tree=tree};
    }finally{Marshal.ReleaseComObject(analysis);}}finally{Marshal.ReleaseComObject(designs);}
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[RCDirectRun]::Run($root,$ExpectedWorkspace,$OutputStem,$AnalysisName)
[IO.File]::WriteAllText("$root/$OutputStem.json",($record|ConvertTo-Json -Depth 60),([Text.UTF8Encoding]::new($false)))
$record|Select-Object workspace,dataset,started_utc,returned_utc,captured_utc,failure,errors,analysis_done|ConvertTo-Json
