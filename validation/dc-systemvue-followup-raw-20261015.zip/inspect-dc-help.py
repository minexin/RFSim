import hashlib, html, json, re, sqlite3, zlib
from pathlib import Path

root = Path(__file__).parent
qch = Path('C:/Program Files/Keysight/SystemVue2023/Help/systemvue.qch')
conn = sqlite3.connect(qch.resolve().as_uri()+'?mode=ro', uri=True)
names = [r[0] for r in conn.execute('SELECT Name FROM FileNameTable')]
selected = [n for n in names if re.search(r'(^|/)(INP|OUT|PORT|NLCAP|NLRES|Nonlinear_Cap|Nonlinear_Res|DC_Analysis|Linear_Analysis|TEST_POINT|IPROBE|VDC|IDC)', n, re.I) and n.endswith('.html')]
records=[]
for name in selected:
    fid, = conn.execute('SELECT FileId FROM FileNameTable WHERE Name=?', (name,)).fetchone()
    raw, = conn.execute('SELECT Data FROM FileDataTable WHERE Id=?', (fid,)).fetchone()
    data=zlib.decompress(raw[4:])
    txt=html.unescape(re.sub('<[^>]+>', ' ', data.decode('utf-8','replace')))
    txt=re.sub(r'\s+', ' ', txt).strip()
    records.append(dict(resource=name,sha256=hashlib.sha256(data).hexdigest(),text=txt))
out=root/'dc-help-port-model-resources.json'
with out.open('x',encoding='utf-8') as f:json.dump(records,f,indent=2,ensure_ascii=False)
for r in records:
    if re.search(r'rfdesign/(INP|OUT|PORT|NLCAP|NLRES|TEST_POINT)',r['resource'],re.I):
        print(r['resource'],r['text'][:16000])
print('ALL MATCHING RESOURCES:',*[r['resource'] for r in records],sep='\n')
