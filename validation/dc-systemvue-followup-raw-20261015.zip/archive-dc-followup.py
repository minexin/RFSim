"""One-off evidence packaging; never attaches to SystemVue or runs an analysis."""
import copy, hashlib, json, math, re, zipfile
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as E

repo=Path('D:/project/RFModel')
b=Path(__file__).parent
dest=repo/'validation'
def read(name):return json.loads((b/name).read_text(encoding='utf-8-sig'))
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,indent=2,ensure_ascii=False,allow_nan=False);f.write('\n')
def walk(n):
    yield n
    for c in n.get('children',[]):yield from walk(c)
def dataset(j,name=None):
    name=name or j.get('dataset')
    node=next(n for n in walk(j['tree']) if n['name']==name)
    values={n['name']:n['vars'] for n in walk(node) if 'Data' in n['vars']}
    return node,values
def arr(values,name):return values[name]['Data']['values']
def topology(j,dn):
    x=E.fromstring(j.get('input_xml',j['xml']))
    d=x.find(f'.//Item[@XName="{dn}"][@Type="Design"]')
    return [{'part':p.attrib['XName'],'model':p.findtext('Model'),'netlist':p.findtext('Netlist')}
        for p in d.findall('Item[@XName="PartList"]/Item[@Type="Part"]')]
def cx(z):return {'real':z.real,'imag':z.imag}
def compare(a,e):
    err=abs(a-e);threshold=2e-12*max(1,abs(a),abs(e))
    return dict(observed=cx(a),expected=cx(e),abs_error=err,threshold=threshold,passed=err<=threshold)
def analytic(f):
    s=2j*math.pi*f;a=.003+s*5e-9;c=-.002-s*4e-9;d=.005+s*6e-9
    determinant=a*d-c*c;v1=.001*d/determinant;v2=-.001*c/determinant
    return v1,v2,(1-v1)/1000,.001/v1

# Restoration is judged from fresh readback, not the errored OpenWorkspace return.
original=E.parse(b/'session-preserved-before.wsv').getroot()
restored_record=read('session-after-official-open.json')
restored=E.fromstring(restored_record['xml'])
ui_tags={'ClientWnd','Time','DVport','PVPort','Window','Selected'}
def canonical(n):
    return (n.tag,tuple(sorted(n.attrib.items())),(n.text or '').strip(),
        tuple(canonical(c) for c in n if c.tag not in ui_tags))
restoration=dict(observed_utc=restored_record['utc'],workspace=restored_record['workspace'],
    original_copy_sha256=sha((b/'session-preserved-before.wsv').read_bytes()),
    opened_copy_sha256=sha((b/'session-restored-copy.wsv').read_bytes()),
    original_copy_bytes_unchanged=(b/'session-preserved-before.wsv').read_bytes()==(b/'session-restored-copy.wsv').read_bytes(),
    semantic_content_equal=canonical(original)==canonical(restored),
    ignored_ui_only_fields=sorted(ui_tags),analysis_done=restored_record['analysis_done'],errors=restored_record['errors'],
    design_items=[n.attrib for n in restored.findall('Item[@XName="Designs"]/Item')],
    raw_readback='session-after-official-open.json',
    failures_retained=['session-restoration-timeout.json','session-after-restore-timeout.json','restore-official.stderr.log'],
    recovery_note='Initial DeleteAllInternal helper did not return and was terminated; readback still contained the saved diagnostics. Official OpenWorkspace returned an internal error, but subsequent independent readback proved the original empty design/equations and idle error-free state were restored. Only viewport/window/selection/time differences are excluded.')
assert restoration['original_copy_bytes_unchanged'] and restoration['semantic_content_equal']
assert restoration['analysis_done']==1 and restoration['errors']==''
write(b/'session-restoration-verification.json',restoration)

attempts=[]
special=read('divider-after-script-timeout.json')
_,sv=dataset(special,'LinearDCProbe_Data')
attempts.append(dict(name='divider-no-port',capture='divider-after-script-timeout.json',
    analysis_submitted=True,analysis_done=special['analysis_done'],errors=special['errors'],dataset_variables=list(sv),
    result='failed_no_ports',interpretation='VBScript helper timed out; later readback proves a failed analysis did execute. No solved V/I was produced.'))
outcomes={
    'divider-internal-dc':'model_creation_failed_NLRES',
    'divider-linear-control':'linear_analysis_completed_but_no_solved_DC_VI',
    'cubic-current-entry':'model_creation_failed_NLRES',
    'cubic-charge-entry':'model_creation_failed_NLCAP',
    'rc-physical-ac':'flat_spectrum_export_not_accepted_as_physical_reference',
    'rc-hierarchy-ac':'no_spectra_wrong_output_property_type',
    'rc-hierarchy-physical':'voltage_exported_numeric_comparison_failed'}
for stem,outcome in outcomes.items():
    j=read(stem+'.json');node,values=dataset(j)
    attempts.append(dict(name=stem,capture=stem+'.json',input_workspace=stem+'-input.wsv',result_workspace=stem+'-result.wsv',
        started_utc=j['started_utc'],returned_utc=j['returned_utc'],captured_utc=j['captured_utc'],
        analysis_submitted=True,analysis_done=j['analysis_done'],dataset=j['dataset'],dataset_timestamp=node['vars'].get('TimeStamp'),
        failure=j['failure'],errors=j['errors'],dataset_variables=list(values),result=outcome,vendor_numeric_pass=False))

j=read('rc-hierarchy-physical.json');node,values=dataset(j)
ids=dict(zip(arr(values,'IDNo'),arr(values,'IDName')))
comparisons=[]
for frequency,tag in [(1000,'RC_1k'),(1000000,'RC_1M')]:
    selected=[]
    for physical_node in [1,2]:
        id_value=next(k for k,v in ids.items() if f'Source.{tag}' in v and (v.endswith(',Source') if physical_node==1 else v.endswith(',Source,RCblock')))
        frequencies=arr(values,f'F{physical_node}');identities=arr(values,f'ID{physical_node}');voltage=arr(values,f'V{physical_node}')
        indices=[i for i,k in enumerate(identities) if k==id_value]
        assert len(indices)==2
        raw=[complex(voltage[2*i],voltage[2*i+1]) for i in indices]
        assert raw[0]==raw[1]
        selected.append(dict(node=physical_node,spectrum_id=id_value,spectrum_name=ids[id_value],
            raw_array_indices_zero_based=indices,exported_axis_hz=[frequencies[i] for i in indices],
            center_row_present=frequency in frequencies,raw_voltage_peak=cx(raw[0]),voltage_rms=cx(raw[0]/math.sqrt(2))))
    v1=complex(**{}) if False else complex(**{'real':selected[0]['voltage_rms']['real'],'imag':selected[0]['voltage_rms']['imag']})
    v2=complex(**{'real':selected[1]['voltage_rms']['real'],'imag':selected[1]['voltage_rms']['imag']})
    observed=[v1,v2,(1-v1)/1000,.001/v1];reference=analytic(frequency)
    checks={name:compare(a,e) for name,a,e in zip(['V1_rms_volt','V2_rms_volt','source_current_derived_amp','Y1_including_Rs_derived_siemens'],observed,reference)}
    comparisons.append(dict(source_center_hz=frequency,observations=selected,checks=checks,
        passed=all(c['passed'] for c in checks.values()),
        axis_rule='Documented center-frequency characterization; raw CW edge values retained without interpolation. Frequency correspondence is not accepted as verified.',
        lower_edge_diagnostic_voltage_errors=[abs(observed[k]-analytic(frequency-.5)[k]) for k in (0,1)]))
assert all(not c['passed'] for c in comparisons)
raw_export={k:values[k] for k in ['IDNo','IDName','IDTag','F1','V1','Z1','P1','ID1','F2','V2','Z2','P2','ID2','DC_V','DC_I','LogOutput']}
rc=dict(capture='rc-hierarchy-physical.json',analysis_done=j['analysis_done'],errors=j['errors'],
    topology={'core':topology(j,'RC_Core'),'top':topology(j,'RC_Hierarchy')},
    parameter_readback='rc-hierarchy-output-prepared.json',
    conductance_siemens=[[.003,-.002],[-.002,.005]],capacitance_farad=[[5e-9,-4e-9],[-4e-9,6e-9]],
    source=dict(thevenin_rms_volt=1,resistance_ohm=1000,available_power_watt=.00025,frequency_hz=[1000,1000000]),
    reference_definition='Vs/Rs Norton injection with the physical Rs conductance included once. Analytic 2x2 determinant formulas match the unchanged native fixture.',
    tolerance='abs(actual-expected) <= 2e-12*max(1,abs(actual),abs(expected))',
    direct_voltage_export=True,direct_current_export=False,current_export='Derived from raw node voltage and known source resistance, not a vendor current channel.',
    Y_export='Derived as (Vs/Rs)/V1 from raw voltage; includes physical source conductance. Not an independent vendor Y output.',
    s_parameters_used=False,numeric_pass=False,comparisons=comparisons,raw_dataset_extract=raw_export,
    limitations=['Both source identities export identical complex voltages despite distinct frequencies.',
        'CW center rows are absent even with Pts=3 and typed UseSourcePts=true; all raw edge and plotting-floor rows are retained.',
        'Z2 toward Probe is exported as 1e10 ohm. This does not establish an ideal nonloading probe; its implementation/boundary must be resolved before an equivalent-circuit claim.',
        'The flat setup used Spectrasys loops; its source-direction and branch-direction totals cannot be silently substituted for complete physical node voltages.',
        'This RC diagnostic does not solve or validate nonlinear DC bias.'])

help_files=['circuit-co-simulation-detail-help.json','dc-help-port-model-resources.json','circuit-link-and-propagation-help.json','rc-hierarchy-source-help.json']
help_resources={}
for file in help_files:
    for resource in read(file):
        if 'resource' in resource and 'sha256' in resource:help_resources[resource['resource']]=resource['sha256']
readiness=json.loads((dest/'dc-bias-systemvue-readiness-20261015.json').read_text(encoding='utf-8-sig'))
registry=read('registry-live.json')
entry={}
for stem in ['cubic-current','cubic-charge']:
    prepared=read(stem+'-prepared.json')
    entry[stem]=[{k:v for k,v in op.items() if k!='xml'} for op in prepared['operations']]

report=dict(schema_version=1,classification='vendor_diagnostic_acquired_DC_blocked_RC_not_accepted',
    created_utc=datetime.now(timezone.utc).isoformat(),base_code_commit='dddc0593961b3d734ee7702d96ee9d4ca370519a',systemvue_version=readiness['systemvue_version'],
    ci_evidence='dc-phd-ci-dddc059-20261015.json',native_code_changed=False,native_tolerances_changed=False,rfamp_analyses_submitted=0,
    analysis_submissions=len(attempts),vendor_numeric_comparisons_passed=0,
    acceptance=dict(complete=False,divider_bias=False,cubic_current_bias=False,cubic_charge_derivative=False,RC_small_signal=False,S_comparison=False),
    product_boundary=dict(help_qch=readiness['help_qch'],resources_sha256=help_resources,
        decisive_resource='sim/Non-Linear_Co-Simulation.html',
        interpretation='Installed SystemVue 2023 help restricts nonlinear circuit co-simulation to X-parameter models and directs general nonlinear circuit simulation to Genesys. Registry entries and parameter readback do not establish usable solver support.',
        license_failure_inferred=False,scope='Installed SystemVue 2023 RF circuit co-simulation path; not a claim about all other SystemVue APIs or product versions.'),
    model_entry=dict(registry_capture='registry-live.json',parameters=entry,
        polynomial_format_clue='Genesys 2010 part catalog pp.237/241 uses C=[k,a_k,...,a_n]; [1,.001,0,.002] is the current-entry candidate.',
        external_format_source='https://edadownload.software.keysight.com/eedl/Genesys/2010_05/pdf/part.pdf',
        charge_semantics_verified=False,charge_note='NLCAP accepted a coefficient array but did not create a simulation model. Q(v) versus C(v) semantics remain unverified. The charge entry was a separate probe on the dummy-port node, not a completed combined cubic-bias fixture.',
        topologies={stem:topology(read(stem+'.json'),'DC_Divider') for stem in ['divider-linear-control','cubic-current-entry','cubic-charge-entry']},
        dc_output_note='Linear control returned F/S/ZPORT and no solved node V or terminal I. IPROBE.IDC and TEST_POINT.VDC stayed input parameters; Spectrasys DC_V/DC_I are supply budgets.'),
    attempts=attempts,rc_diagnostic=rc,session_restoration=restoration,
    next_required=['A supported general nonlinear circuit reference that accepts the exact I(v) and Q(v) laws and exports solved node voltage and terminal current.',
        'Resolve RC frequency propagation and probe boundary on the vendor path before reusing its voltages as an equivalent physical reference.',
        'Reapply the unchanged V/I/derivative/Y criteria; only compare S after physical quantities and references pass.'])

# Preserve every owned raw file. Copyrighted vendor help/PDF/page images stay local
# with hashes; no vendor manual is redistributed in the repository archive.
excluded={p.name for p in b.iterdir() if p.is_file() and (p.suffix.lower() in {'.pdf','.png'} or ('help' in p.name and p.suffix=='.json'))}
manifest=[]
for p in sorted(b.iterdir(),key=lambda p:p.name.casefold()):
    if not p.is_file():continue
    data=p.read_bytes();manifest.append(dict(path=p.name,bytes=len(data),sha256=sha(data),archived=p.name not in excluded,
        classification='local_vendor_documentation_only' if p.name in excluded else 'owned_diagnostic_capture_or_procedure'))
archive=dest/'dc-systemvue-followup-raw-20261015.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for m in manifest:
        if m['archived']:z.write(b/m['path'],m['path'])
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={m['path'] for m in manifest if m['archived']}
    for m in manifest:
        if m['archived']:assert sha(z.read(m['path']))==m['sha256']
archive_info=dict(path=archive.name,sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size,
    included_files=sum(m['archived'] for m in manifest),local_only_files=sum(not m['archived'] for m in manifest),
    local_raw_root=b.relative_to(repo).as_posix(),crc_and_sha256_verified=True,
    note='All task-owned captures, input/result workspaces, scripts and failure logs are included. Vendor documentation is retained locally and identified by hashes only. Scripts document attempted procedures and must not be run blindly; some intentionally retained attempts failed.')
report['raw_archive']=archive_info
write(dest/'dc-systemvue-followup-manifest-20261015.json',dict(schema_version=1,archive=archive_info,files=manifest))
write(dest/'dc-systemvue-followup-20261015.json',report)
print(json.dumps(dict(archive=archive_info,restoration_verified=restoration['semantic_content_equal'],
    attempts=len(attempts),accepted_comparisons=0,voltage_errors={str(c['source_center_hz']):{k:v['abs_error'] for k,v in c['checks'].items()} for c in comparisons}),indent=2))
