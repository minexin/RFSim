import copy, hashlib, html, json, re, sqlite3, zlib
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as E

b=Path(__file__).parent
x=E.fromstring(json.loads((b/'rc-physical-ac.json').read_text())['input_xml'])
out=E.Element('Item',{'XName':'Designs','Type':'Folder'})
def item(p,n,t): return E.SubElement(p,'Item',{'XName':n,'Type':t})
def field(p,n,v,t=None):
    q=E.SubElement(p,n)
    if t:
        E.SubElement(q,'T').text=t; E.SubElement(q,'D').text=str(v)
    else:q.text=str(v)
    return q
def setparam(p,n,v,t=None):
    q=p.find(f'Item[@XName="{n}"]')
    if q is None:q=item(p,n,'PartParam' if p.attrib.get('Type')=='ParamSet' else 'Param')
    for c in list(q):
        if c.tag in ('Data','DataEntry'):q.remove(c)
    field(q,'Data' if t else 'DataEntry',v,t)
    return q
core=item(out,'RC_Core','Design');field(core,'Intent',1,'Int');cp=item(core,'PartList','PartList')
flat=x.find('.//Item[@XName="RC_Physical"][@Type="Design"]/Item[@XName="PartList"]')
for n in ('C1','R12','C12','R2','C2'):cp.append(copy.deepcopy(flat.find(f'Item[@XName="{n}"]')))
for n,model,num,node,z in [('Input','*INP',1,1,50),('Output','*OUT',2,2,75)]:
    p=item(cp,n,'Part');field(p,'Model',model);field(p,'Netlist',f'Port_1,{node}');field(p,'Symbol','INPUT' if num==1 else 'OUTPUT')
    ps=item(p,'ParamSet','ParamSet');setparam(ps,'PORT',num,'Int');zq=setparam(ps,'ZO',z);field(zq,'Unit',2000,'Int');setparam(ps,'ZFreq',0,'Double')
top=item(out,'RC_Hierarchy','Design');field(top,'Intent',1,'Int');tp=item(top,'PartList','PartList')
source=copy.deepcopy(flat.find('Item[@XName="Source"]'));tp.append(source)
setparam(source.find('Item[@XName="ParamSet"]'),'Pts','3')
block=item(tp,'RCblock','Part');field(block,'Model','RC_Core');field(block,'Netlist','Input,1|Output,2');field(block,'Symbol','2-PortNoGnd');field(block,'SimOverride',0,'Int');item(block,'ParamSet','ParamSet')
probe=item(tp,'Probe','Part');field(probe,'Model','TEST_POINT');field(probe,'Netlist','Port_1,2');field(probe,'Symbol','TEST_POINT');item(probe,'ParamSet','ParamSet')
a=copy.deepcopy(x.find('.//Item[@XName="RCSystem"][@Type="System Analysis"]'));a.attrib['XName']='RCHierarchy';a.attrib['UserName']='RCHierarchy'
for n,v in [('DesignName','RC_Hierarchy'),('DataName','RCHierarchy_Data'),('MaxOrder','3')]:setparam(a,n,v)
for n,v in [('UseSourcePts',1),('DataLevels',1)]:setparam(a,n,v,'Int')
setparam(a,'DataParts','1;3;Source;RCblock;Probe','Array_BString');out.append(a)
xml=E.tostring(out,encoding='utf-8',xml_declaration=True)
with (b/'rc-hierarchy-entry.xml').open('xb') as f:f.write(xml)
qch=Path('C:/Program Files/Keysight/SystemVue2023/Help/systemvue.qch');c=sqlite3.connect(qch.as_uri()+'?mode=ro',uri=True)
records=[]
for name in ['rfdesign/MultiSource.html','sim/Linear_Co-Simulation.html']:
    fid=c.execute('SELECT FileId FROM FileNameTable WHERE Name=?',(name,)).fetchone()[0]
    raw=zlib.decompress(c.execute('SELECT Data FROM FileDataTable WHERE Id=?',(fid,)).fetchone()[0][4:])
    txt=re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',raw.decode('utf-8','replace'))))
    records.append(dict(resource=name,sha256=hashlib.sha256(raw).hexdigest(),text=txt))
with (b/'rc-hierarchy-source-help.json').open('x',encoding='utf-8') as f:json.dump(records,f,indent=2)
plan=dict(created_utc=datetime.now(timezone.utc).isoformat(),classification='pre_acquisition_supported_linear_subcircuit',input_sha256=hashlib.sha256(xml).hexdigest(),
    reason='Installed Linear_Co-Simulation help requires pure linear components in a subcircuit for circuits with loops. MultiSource remains at the top level.',
    unchanged_physics='Same five RC parts. Rs=1000 ohm is the source internal R once. Two 1 V RMS Thevenin tones at 1 kHz and 1 MHz. No external output termination.',
    ports='Core Input/Output 50/75 ohm references expose node 1/2 at RCblock. Top Probe is a voltage TEST_POINT; no matched output port.',
    frequency_rule='Use exact source center rows if exported. Linear co-simulation characterizes at each input spectrum center and uses that response across its bandwidth, per installed help. Preserve all edge/plot-floor rows.',
    tolerance='abs(actual-expected) <= 2e-12*max(1,abs(actual),abs(expected)); unchanged',
    current_rule='No S-derived V/I. Derivations from independent vendor V and the physical resistors must be labelled derived; no direct current claim without a current output.')
with (b/'rc-hierarchy-plan.json').open('x',encoding='utf-8') as f:json.dump(plan,f,indent=2)
print(json.dumps(plan,indent=2))
for r in records[:1]:
    for m in re.finditer(r'Number of (Source )?Points|source points|UseSourcePts',r['text'],re.I):print(r['text'][max(0,m.start()-100):m.end()+420])
