$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($n in @('divider-noport-failed.wsv','divider-nonlinear-prepared.wsv','divider-nonlinear-prepared.json')) {if(Test-Path -LiteralPath "$root/$n"){throw "Refuse to overwrite $n"}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class NonlinearDividerPrepare {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 static object Set(GENESYS.IItem part,string name,string text){var ps=part.GetItemByName("ParamSet");try{var p=ps.GetItemByName(name);try{Call(p,"Set",text);return Call(p,"GetValue");}finally{Marshal.ReleaseComObject(p);}}finally{Marshal.ReleaseComObject(ps);}}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");
   var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!="divider-prepared"||!Convert.ToBoolean(Call(w,"IsAnalysisDone")))throw new Exception("Unexpected or active session");
    w.SaveAs(path+"/divider-noport-failed.wsv");
    string errorsBefore=m.GetErrors();File.WriteAllText(path+"/divider-nonlinear-errors-before.txt",errorsBefore);Call(w,"ClearErrorLog");
    var ops=new List<object>();string failure=null;
    try{
     var designs=root.GetItemByName("Designs");try{var design=designs.GetItemByName("DC_Divider");try{var parts=design.GetItemByName("PartList");try{
      parts.FromXML(File.ReadAllText(path+"/divider-dummy-port-entry.xml"));
      var dummy=parts.GetItemByName("DummyLoad");try{Call(dummy,"ChangeModel","RES");ops.Add(new{name="DummyLoad.R",value=Set(dummy,"R","50"),xml=dummy.ToXML()});}finally{Marshal.ReleaseComObject(dummy);}
      var load=parts.GetItemByName("RL");try{
       Call(load,"DeleteParams");Call(load,"ChangeModel","NLRES");
       Set(load,"TYPE","2");Set(load,"MODELTYPE","0");
       ops.Add(new{name="RL.C",value=Set(load,"C","[1;0.0005]"),xml=load.ToXML()});
      }finally{Marshal.ReleaseComObject(load);}
     }finally{Marshal.ReleaseComObject(parts);}}finally{Marshal.ReleaseComObject(design);}}finally{Marshal.ReleaseComObject(designs);}
    }catch(Exception e){failure=e.ToString();}
    string xml=root.ToXML();w.SaveAs(path+"/divider-nonlinear-prepared.wsv");
    return new{utc=DateTime.UtcNow.ToString("o"),workspace=root.GetName(),analysis_requested=false,errors_before=errorsBefore,errors=m.GetErrors(),failure=failure,operations=ops,xml=xml};
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[NonlinearDividerPrepare]::Run($root)
[IO.File]::WriteAllText("$root/divider-nonlinear-prepared.json",($record|ConvertTo-Json -Depth 20),([Text.UTF8Encoding]::new($false)))
$record|Select-Object workspace,failure,errors,operations|ConvertTo-Json -Depth 12
