$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($s in @('rc-expressions-prepared.wsv','rc-expressions-prepared.json')){if(Test-Path -LiteralPath "$root/$s"){throw 'Evidence exists'}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class RCExpressionPrepare {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 static object Set(GENESYS.IItem part,string name,object value,bool si){var ps=part.GetItemByName("ParamSet");try{var p=ps.GetItemByName(name);try{
   Call(p,si?"SetValue":"Set",value);return new{name=part.GetName()+"."+name,method=si?"SetValue":"Set",assigned=value,parsed=Call(p,"GetValue"),display=Call(p,"Get"),xml=p.ToXML()};
 }finally{Marshal.ReleaseComObject(p);}}finally{Marshal.ReleaseComObject(ps);}}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!="rc-physical-prepared"||!Convert.ToBoolean(Call(w,"IsAnalysisDone")))throw new Exception("Unexpected or active session");
    string errorsBefore=m.GetErrors();File.WriteAllText(path+"/rc-expressions-errors-before.txt",errorsBefore);Call(w,"ClearErrorLog");
    var ops=new List<object>();string failure=null;
    try{var designs=root.GetItemByName("Designs");try{
     // The dedicated RC design is already loaded; preserve its previous failed-entry state.
     var design=designs.GetItemByName("RC_Physical");try{var parts=design.GetItemByName("PartList");try{
      string[] names={"C1","R12","C12","R2","C2"};string[] models={"CAP","RES","CAP","RES","CAP"};
      string[] values={"1000","500","4000","333.33333333333331","2000"};
      for(int i=0;i<names.Length;i++){var p=parts.GetItemByName(names[i]);try{Call(p,"ChangeModel",models[i]);ops.Add(Set(p,models[i]=="CAP"?"C":"R",values[i],false));}finally{Marshal.ReleaseComObject(p);}}
      var s=parts.GetItemByName("Source");try{
       string[] ns={"Name","Enable","SrcType","MultiCarrier","EnablePN","Freq","BW","Pwr","Phase","RefClk","R","ZO","PORT","POff","PhOff"};
       string[] vs={"=[\"RC_1k\",\"RC_1M\"]","[1;1]","[0;0]","[0;0]","[0;0]","[0.001;1]","[0.000001;0.000001]","[-6.020599913279624;-6.020599913279624]","[0;0]","=[\"\",\"\"]","1000","1000","1","0","0"};
       for(int i=0;i<ns.Length;i++)ops.Add(Set(s,ns[i],vs[i],false));
      }finally{Marshal.ReleaseComObject(s);}
     }finally{Marshal.ReleaseComObject(parts);}}finally{Marshal.ReleaseComObject(design);}
    }finally{Marshal.ReleaseComObject(designs);}}catch(Exception e){failure=e.ToString();}
    string xml=root.ToXML();w.SaveAs(path+"/rc-expressions-prepared.wsv");
    return new{utc=DateTime.UtcNow.ToString("o"),workspace=root.GetName(),analysis_requested=false,errors_before=errorsBefore,errors=m.GetErrors(),failure=failure,operations=ops,xml=xml};
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[RCExpressionPrepare]::Run($root)
[IO.File]::WriteAllText("$root/rc-expressions-prepared.json",($record|ConvertTo-Json -Depth 25),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;failure=$record.failure;errors=$record.errors;operations=@($record.operations|Select-Object name,method,assigned,parsed,display)}|ConvertTo-Json -Depth 8
