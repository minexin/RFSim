$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($n in @('session-preserved-before.wsv','entry-loaded.wsv','entry-probe.json')) {if(Test-Path -LiteralPath "$root/$n"){throw "Refuse to overwrite $n"}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;
public static class EntryProbe {
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);
   vars[item.GetVarName(i)]=v is ValueType||v is string||v is Array||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){
   var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}
  }
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 static void Phase(string path,string text){File.AppendAllText(path+"/entry-phases.log",DateTime.UtcNow.ToString("o")+" "+text+Environment.NewLine);Console.Error.WriteLine(text);}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{
   var app=(GENESYS.Application)active;var m=app.Manager;
   try{
    if(m.GetWorkspaceCount()!=1)throw new Exception("Expected exactly one original workspace");
    var before=m.GetWorkspaceByIndex(0);
    try{
     if(((GENESYS.IItem)before).GetName()!="session-blank-before")throw new Exception("Unexpected original session; preserve it");
     bool done=Convert.ToBoolean(before.GetType().InvokeMember("IsAnalysisDone",BindingFlags.InvokeMethod,null,before,new object[0]));
     if(!done||!String.IsNullOrEmpty(m.GetErrors()))throw new Exception("Session not idle/error-free; preserve it");
     Phase(path,"save-original-session");before.SaveAs(path+"/session-preserved-before.wsv");
    }finally{Marshal.ReleaseComObject(before);}
    Phase(path,"open-dedicated-model-entry-probe-no-analysis");
    m.FileOpen(path+"/RFModel_DC_Entry_Probe.wsv");
    if(m.GetWorkspaceCount()!=1)throw new Exception("Unexpected workspace count after open; preserve sessions");
    var w=m.GetWorkspaceByIndex(0);
    try{
     var item=(GENESYS.IItem)w;
     string errors=m.GetErrors();
     Phase(path,"capture-loaded-entry-and-errors");
     var data=Read(item,7);
     string xml=item.ToXML();
     w.SaveAs(path+"/entry-loaded.wsv");
     return new{utc=DateTime.UtcNow.ToString("o"),analysis_submitted=false,workspace=item.GetName(),errors=errors,xml=xml,tree=data};
    }finally{Marshal.ReleaseComObject(w);}
   }finally{Marshal.ReleaseComObject(m);}
  }finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[EntryProbe]::Run($root)
$json=$record|ConvertTo-Json -Depth 32
[IO.File]::WriteAllText("$root/entry-probe.json",$json,([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;errors=$record.errors;analysis_submitted=$record.analysis_submitted}|ConvertTo-Json
