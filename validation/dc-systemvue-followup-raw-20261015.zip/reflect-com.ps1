$path='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
$a=[Reflection.Assembly]::LoadFrom($path)
foreach($t in $a.GetTypes()) {
 if($t.IsInterface -and $t.Name -match 'Application|Manager|Workspace|Design|Analysis|Item') {
  $t.FullName
  $t.GetMethods() | ForEach-Object {$_.ToString()}
 }
}
