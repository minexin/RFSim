$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($s in @('rc-hierarchy-prepared.wsv','rc-hierarchy-prepared.json')){if(Test-Path -LiteralPath "$root/$s"){throw 'Evidence exists'}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;using System.Collections.Generic;using System.Runtime.InteropServices;using System.Reflection;using System.IO;
public static class RCHierarchyPrepare {
 static object Call(object o,string n,params object[] a){return o.GetType().InvokeMember(n,BindingFlags.InvokeMethod,null,o,a);}
 static object Read(GENESYS.IItem parent,string name){var p=parent.GetItemByName(name);try{return new{name=parent.GetName()+"."+name,parsed=Call(p,"GetValue"),display=Call(p,"Get"),xml=p.ToXML()};}finally{Marshal.ReleaseComObject(p);}}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{var app=(GENESYS.Application)active;var m=app.Manager;try{
   if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");var w=m.GetWorkspaceByIndex(0);try{
    var root=(GENESYS.IItem)w;
    if(root.GetName()!="rc-physical-ac-result"||!Convert.ToBoolean(Call(w,"IsAnalysisDone")))throw new Exception("Unexpected or active session");
    string errorsBefore=m.GetErrors();File.WriteAllText(path+"/rc-hierarchy-errors-before.txt",errorsBefore);Call(w,"ClearErrorLog");
    var ops=new List<object>();string failure=null;
    try{var designs=root.GetItemByName("Designs");try{
     designs.FromXML(File.ReadAllText(path+"/rc-hierarchy-entry.xml"));
     foreach(string dn in new[]{"RC_Core","RC_Hierarchy"}){var d=designs.GetItemByName(dn);try{var parts=d.GetItemByName("PartList");try{
      for(int i=0;i<parts.GetItemCount();i++){var p=parts.GetItemByIndex(i);try{
       string pn=p.GetName();if(pn=="Probe")Call(p,"ChangeModel","TEST_POINT");
       var ps=p.GetItemByName("ParamSet");try{
        string[] ns=pn=="Source"?new[]{"R","ZO","PORT","Freq","Pwr","BW","Pts","Phase","SrcType","Enable"}:pn.StartsWith("C")?new[]{"C"}:pn=="R12"||pn=="R2"?new[]{"R"}:pn=="Input"||pn=="Output"?new[]{"PORT","ZO"}:pn=="Probe"?new[]{"VDC"}:new string[0];
        foreach(string n in ns)ops.Add(new{design=dn,part=pn,readback=Read(ps,n)});
       }finally{Marshal.ReleaseComObject(ps);}
       ops.Add(new{design=dn,part=pn,xml=p.ToXML()});
      }finally{Marshal.ReleaseComObject(p);}}
     }finally{Marshal.ReleaseComObject(parts);}}finally{Marshal.ReleaseComObject(d);}}
     var a=designs.GetItemByName("RCHierarchy");try{foreach(string n in new[]{"DesignName","MaxOrder","UseSourcePts","DataLevels","DataParts","NominalZ0","UsePrevSolution"})ops.Add(Read(a,n));}finally{Marshal.ReleaseComObject(a);}
    }finally{Marshal.ReleaseComObject(designs);}}catch(Exception e){failure=e.ToString();}
    string xml=root.ToXML();w.SaveAs(path+"/rc-hierarchy-prepared.wsv");
    return new{utc=DateTime.UtcNow.ToString("o"),workspace=root.GetName(),analysis_requested=false,errors_before=errorsBefore,errors=m.GetErrors(),failure=failure,operations=ops,xml=xml};
   }finally{Marshal.ReleaseComObject(w);}
  }finally{Marshal.ReleaseComObject(m);}}finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[RCHierarchyPrepare]::Run($root)
[IO.File]::WriteAllText("$root/rc-hierarchy-prepared.json",($record|ConvertTo-Json -Depth 30),([Text.UTF8Encoding]::new($false)))
$record|Select-Object utc,workspace,failure,errors|ConvertTo-Json
