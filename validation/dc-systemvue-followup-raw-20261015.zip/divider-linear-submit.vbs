Dim wsdoc
Set wsdoc = Application.Manager.GetWorkspaceByIndex(0)
Call wsdoc.Designs.LinearDCProbe.ClearModelCache()
Call wsdoc.Designs.LinearDCProbe.RunAnalysis()
