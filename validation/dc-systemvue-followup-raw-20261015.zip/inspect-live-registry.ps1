param([Parameter(Mandatory=$true)][string]$Output)
$ErrorActionPreference='Stop'
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
if (Test-Path -LiteralPath $Output) { throw 'Refuse to overwrite registry evidence' }
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
public static class LiveRegistry {
 public static object Run() {
  object active=Marshal.GetActiveObject("Genesys.Application");
  try {
   var manager=((GENESYS.Application)active).Manager;
   try {
    if(manager.GetWorkspaceCount()!=1)throw new Exception("Expected one workspace; preserve all sessions");
    var ws=manager.GetWorkspaceByIndex(0);
    try {
     var item=(GENESYS.IItem)ws;
     bool done=Convert.ToBoolean(ws.GetType().InvokeMember("IsAnalysisDone",BindingFlags.InvokeMethod,null,ws,new object[0]));
     if(!done)throw new Exception("Analysis still running");
     var result=new Dictionary<string,object>();
     result["utc"]=DateTime.UtcNow.ToString("o");
     result["workspace_name"]=item.GetName();
     result["workspace_xml"]=item.ToXML();
     result["workspace_methods"]=item.GetMethodList();
     result["errors_before"]=manager.GetErrors();
     object[] args=new object[]{null};
     var modifier=new ParameterModifier(1);modifier[0]=true;
     try {
      result["registered_models_return"]=ws.GetType().InvokeMember("GetRegisteredModels",BindingFlags.InvokeMethod,null,ws,args,new ParameterModifier[]{modifier},null,null);
      result["registered_models_out"]=args[0];
     } catch(Exception e) {result["registered_models_error"]=e.ToString();}
     result["errors_after"]=manager.GetErrors();
     return result;
    } finally {Marshal.ReleaseComObject(ws);}
   } finally {Marshal.ReleaseComObject(manager);}
  } finally {Marshal.ReleaseComObject(active);}
 }
}
'@
$r=[LiveRegistry]::Run()
$s=$r|ConvertTo-Json -Depth 16
$f=[IO.File]::Open($Output,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write)
try{$b=[Text.Encoding]::UTF8.GetBytes($s);$f.Write($b,0,$b.Length)}finally{$f.Dispose()}
[pscustomobject]@{output=$Output;workspace=$r.workspace_name;error_before=$r.errors_before;error_after=$r.errors_after;models_error=$r.registered_models_error}|ConvertTo-Json
