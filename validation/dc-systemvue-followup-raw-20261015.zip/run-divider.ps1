$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($n in @('divider-linear-run.json','divider-linear-run.wsv','divider-linear-submit.vbs')) {if(Test-Path -LiteralPath "$root/$n"){throw "Refuse to overwrite $n"}}
[IO.File]::WriteAllText("$root/divider-linear-helper-pid.txt",[string]$PID)
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;
public static class DividerRun {
 static object Call(object o,string name,params object[] args){return o.GetType().InvokeMember(name,BindingFlags.InvokeMethod,null,o,args);}
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);
   var a=v as Array;
   if(a!=null){var flat=new List<object>();foreach(var e in a)flat.Add(e);var dims=new List<int>();for(int j=0;j<a.Rank;j++)dims.Add(a.GetLength(j));vars[item.GetVarName(i)]=new{dimensions=dims,values=flat};}
   else vars[item.GetVarName(i)]=v is ValueType||v is string||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){
   var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}
  }
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 static void Phase(string path,string text){File.AppendAllText(path+"/divider-linear-phases.log",DateTime.UtcNow.ToString("o")+" "+text+Environment.NewLine);Console.Error.WriteLine(text);}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{
   var app=(GENESYS.Application)active;var m=app.Manager;
   try{
    if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one task workspace");
    var w=m.GetWorkspaceByIndex(0);
    try{
     var item=(GENESYS.IItem)w;
     if(item.GetName()!="divider-prepared")throw new Exception("Unexpected session; no analysis submitted");
     if(!Convert.ToBoolean(Call(w,"IsAnalysisDone"))||m.GetErrors()!="")throw new Exception("Session not idle/error-free");
     string script="Dim wsdoc\r\nSet wsdoc = Application.Manager.GetWorkspaceByIndex(0)\r\nCall wsdoc.Designs.LinearDCProbe.ClearModelCache()\r\nCall wsdoc.Designs.LinearDCProbe.RunAnalysis()\r\n";
     File.WriteAllText(path+"/divider-linear-submit.vbs",script);
     string before=item.ToXML();string started=DateTime.UtcNow.ToString("o"),returned=null,failure=null;
     Phase(path,"submit-single-linear-divider-analysis");
     try{app.RunScript(script,GENESYS.ScriptLanguage.genLangVBScript);returned=DateTime.UtcNow.ToString("o");}
     catch(Exception e){failure=e.ToString();}
     Phase(path,"read-existing-results-without-resubmission");
     object done=Call(w,"IsAnalysisDone");string errors=m.GetErrors();var tree=Read(item,12);string xml=item.ToXML();
     w.SaveAs(path+"/divider-linear-run.wsv");
     return new{started_utc=started,returned_utc=returned,captured_utc=DateTime.UtcNow.ToString("o"),analysis_requested=true,analysis_done=done,workspace=item.GetName(),failure=failure,errors=errors,submitted_script=script,input_xml=before,xml=xml,tree=tree};
    }finally{Marshal.ReleaseComObject(w);}
   }finally{Marshal.ReleaseComObject(m);}
  }finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[DividerRun]::Run($root)
[IO.File]::WriteAllText("$root/divider-linear-run.json",($record|ConvertTo-Json -Depth 60),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;started=$record.started_utc;returned=$record.returned_utc;failure=$record.failure;errors=$record.errors;analysis_done=$record.analysis_done}|ConvertTo-Json
