$ErrorActionPreference='Stop'
$root='D:/project/RFModel/build-reference/dc-systemvue-followup-20261015'
foreach($n in @('RFModel_DC_Entry_API.wsv','entry-api-loaded.wsv','entry-api.json')) {if(Test-Path -LiteralPath "$root/$n"){throw "Refuse to overwrite $n"}}
$interop='C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/Scripting/Excel_to_RF/Interop.GENESYS.dll'
Add-Type -Path $interop
Add-Type -ReferencedAssemblies $interop -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Reflection;
using System.IO;
public static class XmlEntryProbe {
 static object Read(GENESYS.IItem item,int depth) {
  var vars=new Dictionary<string,object>();
  for(int i=0;i<item.GetVarCount();i++){
   object v=item.GetVarValue(i);
   vars[item.GetVarName(i)]=v is ValueType||v is string||v is Array||v==null?v:v.GetType().FullName;
  }
  var children=new List<object>();
  if(depth>0)for(int i=0;i<item.GetItemCount();i++){
   var c=item.GetItemByIndex(i);try{children.Add(Read(c,depth-1));}finally{Marshal.ReleaseComObject(c);}
  }
  return new{name=item.GetName(),methods=item.GetMethodList(),vars=vars,children=children};
 }
 static void Phase(string path,string text){File.AppendAllText(path+"/entry-api-phases.log",DateTime.UtcNow.ToString("o")+" "+text+Environment.NewLine);Console.Error.WriteLine(text);}
 public static object Run(string path){
  object active=Marshal.GetActiveObject("Genesys.Application");
  try{
   var app=(GENESYS.Application)active;var m=app.Manager;
   try{
    if(m.GetWorkspaceCount()!=1)throw new Exception("Expected one saved original session");
    var w=m.GetWorkspaceByIndex(0);
    try{
     var item=(GENESYS.IItem)w;
     if(item.GetName()!="session-preserved-before")throw new Exception("Unexpected session; no edits submitted");
     bool done=Convert.ToBoolean(w.GetType().InvokeMember("IsAnalysisDone",BindingFlags.InvokeMethod,null,w,new object[0]));
     if(!done||!String.IsNullOrEmpty(m.GetErrors()))throw new Exception("Session not idle and error-free");
     Phase(path,"save-dedicated-copy-before-replacing-empty-contents");
     w.SaveAs(path+"/RFModel_DC_Entry_API.wsv");
     Phase(path,"deserialize-constructed-model-entry-XML-with-auto-analysis-disabled");
     string failure=null;
     try{w.DeleteAllInternal();item.FromXML(File.ReadAllText(path+"/RFModel_DC_Entry_Probe.wsv"));}
     catch(Exception e){failure=e.ToString();}
     Phase(path,"capture-types-models-parameters-and-errors-no-analysis-requested");
     string errors=m.GetErrors();var tree=Read(item,8);string xml=item.ToXML();
     w.SaveAs(path+"/entry-api-loaded.wsv");
     return new{utc=DateTime.UtcNow.ToString("o"),analysis_requested=false,workspace=item.GetName(),failure=failure,errors=errors,xml=xml,tree=tree};
    }finally{Marshal.ReleaseComObject(w);}
   }finally{Marshal.ReleaseComObject(m);}
  }finally{Marshal.ReleaseComObject(active);}
 }
}
'@
$record=[XmlEntryProbe]::Run($root)
[IO.File]::WriteAllText("$root/entry-api.json",($record|ConvertTo-Json -Depth 36),([Text.UTF8Encoding]::new($false)))
[pscustomobject]@{workspace=$record.workspace;failure=$record.failure;errors=$record.errors;analysis_requested=$record.analysis_requested}|ConvertTo-Json
