"""Archive this run's owned evidence, not vendor installation files or build products."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
VALIDATION = REPO/'validation'
PREFIX = 'local-takeover'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')

def junit(path):
    element = ET.parse(path).getroot()
    cases = list(element.iter('testcase'))
    failed = [e.get('name') for e in cases if e.find('failure') is not None or e.find('error') is not None]
    skipped = [e.get('name') for e in cases if e.find('skipped') is not None]
    return dict(tests=len(cases), passed=len(cases)-len(failed)-len(skipped), failures=failed,
                skipped=skipped, xml=path.name)

for name in ('Release-fixed', 'Debug-fixed'):
    assert read_json(ROOT/f'ctest-{name}.json')['returncode'] == 0
    result = junit(ROOT/f'ctest-{name}.xml')
    assert result['tests'] == result['passed'] == 150 and not result['skipped']
assert read_json(ROOT/'xparameter-contract-Release-ready.json')['returncode'] == 0
assert 'Ran 38 tests' in (ROOT/'xparameter-contract-Release-ready.log').read_text(encoding='utf-8')
assert read_json(ROOT/'evidence-check-after.json')['returncode'] == 0
assert read_json(ROOT/'evidence-encoding-regression.json')['returncode'] == 0
replay = read_json(ROOT/'xparameter-replay-fixed/replay.json')
assert replay['status'] == 'selected_installed_file_replay_pass'
assert replay['independent_simulations'] == 0 and not replay['numerical_model_compatibility']

source_names = [
    '.github/workflows/build.yml', 'cmake/RFModelTests.cmake',
    'scripts/reference/check_compatibility_evidence.py',
    'scripts/reference/test_compatibility_evidence_encoding.py',
    'scripts/reference/replay-installed-xparameter-evidence.py',
    'scripts/reference/test_xparameter_installed_replay.py',
    'tests/cmake/check_linear_mna_install.cmake',
    'tests/cmake/check_mna_power_wave_s_install.cmake',
    'tests/cmake/check_mna_default_config_install.cmake',
]
source_hashes = {p: sha((REPO/p).read_bytes()) for p in source_names}
# Native headers were not edited; record the exact base and current header identity.
headers = subprocess.check_output(['git','ls-files','include'], cwd=REPO).decode().splitlines()
header_hashes = {p: sha((REPO/p).read_bytes()) for p in headers}
write_json(ROOT/'source-identity.json', {
    'base_commit': '8984da6f9d503b4927888071046ad66c551709a4',
    'base_tree': 'ff723d70b490c5f47105d9ab234e2efa544e7136',
    'scope': 'Base plus working-tree tool/test changes; local bytes bound below, not a claim of post-commit CI.',
    'tool_and_test_sources_sha256': source_hashes,
    'unchanged_native_headers_sha256': header_hashes,
})
patch = subprocess.check_output(['git','diff','--binary','--']+source_names, cwd=REPO)
(ROOT/'tracked-tool-test-changes.patch').write_bytes(patch)

members = {}
def add(path, name):
    if name in members:
        raise ValueError('Duplicate archive member '+name)
    assert path.is_file()
    assert path.suffix.lower() not in ('.mdf','.xnp','.qch','.html','.exe','.dll','.pdb')
    members[name] = path.read_bytes()

allowed_suffixes = {'.json','.log','.xml','.py','.md','.txt','.patch','.draft','.stdout','.stderr'}
for p in ROOT.iterdir():
    if p.is_file() and p.suffix in allowed_suffixes:
        add(p, p.name)
for folder in ('xparameter-replay','xparameter-replay-fixed'):
    for p in (ROOT/folder).rglob('*'):
        relative = p.relative_to(ROOT/folder)
        if p.is_file() and 'build' not in relative.parts:
            add(p, folder+'/'+relative.as_posix())
for folder in ('mna-empty-config-before','xparameter-identity-diagnostic'):
    for p in (ROOT/folder).iterdir():
        if p.is_file() and p.suffix in allowed_suffixes:
            add(p, folder+'/'+p.name)
for p in (REPO/'build-mna-empty-after').iterdir():
    if p.is_file() and p.suffix in allowed_suffixes:
        add(p, 'mna-after/'+p.name)
for name, path in (
    ('native-before-LastTest.log', ROOT/'native/Testing/Temporary/LastTest.log'),
    ('native-Release-fixed-LastTest.log', REPO/'build-1016r/Testing/Temporary/LastTest.log'),
    ('native-Debug-fixed-LastTest.log', REPO/'build-1016d/Testing/Temporary/LastTest.log'),
):
    add(path, name)
for name in source_names:
    add(REPO/name, 'tested-source/'+name)
add(REPO/'validation/systemvue-linear-rfsystem-minimal-plan-20261016.json', 'next-plan.json')

archive = VALIDATION/f'{PREFIX}-raw-20261016.zip'
assert not archive.exists(), 'Never overwrite a retained evidence archive'
rows = []
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
        rows.append(dict(path=name, bytes=len(data), sha256=sha(data)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert z.namelist() == [r['path'] for r in rows]
    for row in rows:
        assert sha(z.read(row['path'])) == row['sha256']
manifest = dict(schema_version=1, archive=dict(path=archive.name, bytes=archive.stat().st_size,
                sha256=sha(archive.read_bytes()), files=len(rows), crc_and_sha256_verified=True),
                classification='owned_source_logs_bounded_format_summaries_and_help_facts',
                excluded='Vendor QCH, full help/HTML, complete MDF/XNP, installation binaries, credentials and licenses.',
                files=rows)
write_json(VALIDATION/f'{PREFIX}-manifest-20261016.json', manifest)
summary = dict(
    schema_version=1,
    classification='local_sync_review_native_regression_and_selected_format_replay',
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    previous_local_commit=subprocess.check_output(['git','rev-parse','6870b47'],cwd=REPO).decode().strip(),
    synchronized_commit='8984da6f9d503b4927888071046ad66c551709a4',
    synchronized_tree='ff723d70b490c5f47105d9ab234e2efa544e7136',
    fast_forward_commits=22, clean_before_sync=True,
    baseline_ci=read_json(ROOT/'baseline-ci-summary.json'),
    native_core_changed=False, historical_expectations_changed=False,
    evidence_identity='Base plus tested-source hashes in archive. This record does not claim CI for the subsequent publication commit.',
    source_hashes=source_hashes,
    local_native_before=junit(ROOT/'ctest-Release.xml'),
    local_native_after={c: dict(**junit(ROOT/f'ctest-{c}-fixed.xml'),
        receipt=read_json(ROOT/f'ctest-{c}-fixed.json')) for c in ('Debug','Release')},
    xparameter_contract=dict(tests=38,passed=38,skipped=0,receipt=read_json(ROOT/'xparameter-contract-Release-ready.json')),
    evidence_check=dict(metadata_mutations_rejected=34,raw_ci_mutations_rejected=40,
                        gbk_regression_tests=1,passed=1),
    mna_targeted=dict(Release=dict(passed=6,tests=6),Debug=dict(passed=5,tests=5),
                     evidence='mna-after/verification.json'),
    installed_xparameter=dict(status=replay['status'],files=4,unique_content_hashes=3,
        independent_simulations=0,numerical_model_compatibility=False,
        before='xparameter-replay/replay.json',after='xparameter-replay-fixed/replay.json',
        baseline_sha256='432022e69d4cb1010b27d73b18adc03488d106989f69900ccc5592421963ec59'),
    vendor_help=dict(pages=27,evidence='help-review.json',
        version_observation='2023.0.0.11903',simulation_executed=False),
    new_vendor_analysis_submissions=0, prior_dc_rc_accepted_comparisons=0,
    next_plan='systemvue-linear-rfsystem-minimal-plan-20261016.json',
    archive=manifest['archive'],manifest=f'{PREFIX}-manifest-20261016.json',
    limitations=[
        'Selected installed file format match is not full numerical X-parameter model compatibility.',
        'New shared-circuit plan is frozen, not acquired or accepted.',
        'Local complete native tests cover Windows/MSVC with C API and CLI disabled.',
        'Deep-path MSBuild MAX_PATH failure is retained; short-path rerun is a separate run, not a general long-path fix.',
        'No new release, tag, license, API/ABI stability or full SystemVue coverage decision.',
    ])
write_json(VALIDATION/f'{PREFIX}-validation-20261016.json',summary)
print(json.dumps(dict(archive=manifest['archive'],native=summary['local_native_after'],sources=source_hashes)))
