"""Read-only installed-file metadata diagnostic; no parsing or simulation.

The sole writable fixture/output is next to this script. Existing files are not
overwritten. Vendor paths are opened read-only for metadata; no file bytes are read.
"""
import ctypes
from ctypes import wintypes
import json
import msvcrt
import os
from pathlib import Path
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
VENDOR = Path('C:/Program Files/Keysight/SystemVue2023/Examples/RF Architecture Design/RF Design Kit/X Parameters')
NAMES = ('ZFL_11AD_PHDModel.mdf', 'X-param_BalAmp_ZFL11AD.mdf',
         'Multitone_Volterra_X-device.xnp', 'AMP_Xparams.mdf')
FIELDS = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns',
          'st_birthtime_ns', 'st_mode', 'st_nlink', 'st_file_attributes', 'st_reparse_tag')

class FILE_BASIC_INFO(ctypes.Structure):
    _fields_ = [('CreationTime', ctypes.c_longlong), ('LastAccessTime', ctypes.c_longlong),
                ('LastWriteTime', ctypes.c_longlong), ('ChangeTime', ctypes.c_longlong),
                ('FileAttributes', wintypes.DWORD)]

get_basic = ctypes.WinDLL('kernel32', use_last_error=True).GetFileInformationByHandleEx
get_basic.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
get_basic.restype = wintypes.BOOL

def record(st):
    return {name: getattr(st, name, None) for name in FIELDS}

def native_times(fd):
    info = FILE_BASIC_INFO()
    if not get_basic(wintypes.HANDLE(msvcrt.get_osfhandle(fd)), 0,
                     ctypes.byref(info), ctypes.sizeof(info)):
        raise ctypes.WinError(ctypes.get_last_error())
    return {name + '_ns': (getattr(info, name) - 116444736000000000) * 100
            for name in ('CreationTime', 'LastWriteTime', 'ChangeTime')}

def observe(path, classification):
    before = record(path.stat())
    with path.open('rb') as stream:
        opened = record(os.fstat(stream.fileno()))
        native = native_times(stream.fileno())
        after_fd = record(os.fstat(stream.fileno()))
    after = record(path.stat())
    return {'path': str(path), 'classification': classification,
            'path_before': before, 'fd_before': opened, 'fd_after': after_fd,
            'path_after': after, 'native_file_basic_info': native,
            'path_stable': before == after, 'fd_stable': opened == after_fd,
            'cross_api_differences': [name for name in FIELDS if before[name] != opened[name]],
            'path_ctime_is_native_creation': before['st_ctime_ns'] == native['CreationTime_ns'],
            'fd_ctime_is_native_change': opened['st_ctime_ns'] == native['ChangeTime_ns']}

fixture = ROOT / 'synthetic-file-with-metadata-change.txt'
with fixture.open('xb') as stream:
    stream.write(b'Synthetic diagnostic fixture only.\n')
os.utime(fixture, ns=(1670440969000000000, 1670440969000000000))
report = {'created_utc': datetime.now(timezone.utc).isoformat(),
          'python': sys.version, 'executable': sys.executable,
          'simulation_executed': False, 'vendor_content_read': False,
          'vendor_content_modified': False,
          'records': [observe(VENDOR / name, 'installed_metadata_only') for name in NAMES] +
                     [observe(fixture, 'authored_synthetic_control')]}
with (ROOT / 'diagnostic.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'records': len(report['records']),
                  'all_stable': all(r['path_stable'] and r['fd_stable'] for r in report['records']),
                  'differences': [r['cross_api_differences'] for r in report['records']]}))
