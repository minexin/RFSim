# Windows path/descriptor identity diagnostic (2026-10-16)

The four-file formal replay failed before native parsing. Its original result is
retained in the sibling `xparameter-replay/replay.json`. No original expected
values or vendor files were changed by this diagnostic, and SystemVue was not run.

## Reproduced cause

Interpreter: Python 3.12.14, MSC v.1944 64-bit, the bundled local runtime recorded
in `diagnostic.json`. `diagnose.py` opened the four selected installed vendor files
read-only for metadata only (no content read), plus an authored synthetic control.
All five path snapshots were internally stable, and all five descriptor snapshots
were internally stable. In every case the sole path-versus-descriptor difference
was `st_ctime_ns`. Device, inode, size, mtime, birthtime, mode, nlink, attributes and
reparse tag matched.

`GetFileInformationByHandleEx(FileBasicInfo)` confirmed that path `st_ctime_ns`
equals native CreationTime, whereas descriptor `st_ctime_ns` equals ChangeTime.
For the first installed file these were respectively 1789293285692343000 and
1789293373160809500 ns since the Unix epoch. Both birthtimes equal CreationTime.
This was not a st_dev discrepancy or an observed concurrent modification.

The synthetic control is a newly authored file followed by `os.utime` to ensure
metadata change time differs from creation time. Calling the unmodified current
`read_once` on only that control reproduced `selected_file_changed_before_read`;
see `current-read-once-synthetic-repro.json`. The initial static review did not
exercise this Windows runtime behavior and therefore missed this defect.

Upstream primary evidence independently describes the same Windows discrepancy:
[CPython issue 157671](https://github.com/python/cpython/issues/157671).
The issue discusses the pathname compatibility conversion to birthtime and the
descriptor path retaining change time. This finding remains grounded in our local
native FileBasicInfo observation, not inferred solely from that other version.

## Minimal portable repair

Keep the original complete `identity` record, including ctime, for each observation.
Separate cross-API file binding from same-API mutation detection:

1. Compare pathname-before to descriptor-opened using device, inode, mode, size,
   mtime; on Windows do not compare ctime across APIs. Elsewhere retain the full
   original comparison. Birthtime, when available on both APIs, may additionally
   be compared as an explicit field; it must not replace descriptor ctime.
2. After the one bounded read, require descriptor-opened == descriptor-after using
   the full original identity including ctime. Require pathname-before ==
   pathname-after using its full original identity including ctime.
3. Keep the existing resolved-path/containment, regular-file, byte-length, input
   limit, one-open/one-read, no-retry and exact baseline hash gates unchanged.
4. Record path-before and fd-before/after identities separately (or at least make
   the difference explicit in the diagnosis); a single ctime field must not be
   described as a universal cross-platform change timestamp.

Do not remove ctime globally, equate ctime with birthtime everywhere, tolerate
other identity differences, use a time tolerance, rewrite expected hashes, or
drop one-shot checks. The metadata check is not a filesystem snapshot, as already
documented; the exact byte/hash baseline gate still checks the bytes actually
supplied to the native reader.

## Required regression coverage

- Windows-style stable pathname and descriptor records with differing ctime must
  permit the one bounded read; the same cross-API mismatch on POSIX must fail.
- Independently mutate only pathname ctime and only descriptor ctime across the
  read; both must still fail. These tests prevent an accidental global omission.
- Cross-API device/inode/mode/size/mtime differences must still fail before read.
  Same-API mutation, replacement, resolution escape and byte-count mismatches
  must still fail without retry.
- Real synthetic fixture integration must deliberately change a newly created
  file's metadata before collection. A fixture written once and immediately read
  can have equal creation/change timestamps and miss this defect on Windows.
- Run the full installed-only synthetic gate and then perform a new, separately
  preserved four-file formal replay. Keep the original failed run and baseline.

The initial diagnostic wrote only this directory. The subsequent authorized
repair changed only `scripts/reference/replay-installed-xparameter-evidence.py`,
`scripts/reference/test_xparameter_installed_replay.py` and
`docs/installed-xparameter-replay.md`, implementing the minimal strategy above.
No vendor file, baseline or original failed receipt was changed.

The focused FileIdentityTests run contains ten tests: nine passed and the existing
symlink test skipped because this Windows account lacks symlink privileges. Exact
new output and command status are retained in `identity-tests.stdout`,
`identity-tests.stderr` and `identity-tests.command.json`. An earlier focused
attempt first exposed the synthetic fixture's unresolved ADMINI~1 temporary root;
the test fixture was changed to resolve its root, matching collect()'s existing
production contract. That earlier attempt failed with outside-installation
diagnostics rather than reaching identity checks. The successful rerun confirms
the identity regressions themselves execute. The four-file formal replay is left
to the root agent and has not been repeated by this subagent.
