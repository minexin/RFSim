import datetime
import json
import os
from pathlib import Path
import re
import subprocess

OUTPUT = Path(__file__).resolve().parent
SOURCE = OUTPUT.parents[2]
CMAKE = Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
compiler_files = list((OUTPUT.parent / 'native' / 'CMakeFiles').glob('*/CMakeCXXCompiler.cmake'))
assert len(compiler_files) == 1, compiler_files
compiler = re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)', compiler_files[0].read_text()).group(1)
env = dict(os.environ)
# Explicit dict has one case-normalized PATH entry on Windows.
assert sum(key.upper() == 'PATH' for key in env) <= 1
results = []
for name in ('linear_mna', 'mna_power_wave_s'):
    argv = [str(CMAKE), '-DSOURCE=' + SOURCE.as_posix(),
            '-DBINARY=' + (OUTPUT / name).as_posix(),
            '-DGENERATOR=Visual Studio 17 2022', '-DCOMPILER=' + compiler,
            '-DCONFIG=', '-DMODES=pure', '-P',
            (SOURCE / 'tests' / 'cmake' / ('check_' + name + '_install.cmake')).as_posix()]
    log = OUTPUT / (name + '.log')
    receipt = OUTPUT / (name + '.json')
    if log.exists() or receipt.exists():
        raise RuntimeError('Refusing to overwrite prior evidence: ' + name)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START ' + name, flush=True)
    with log.open('xb') as stream:
        process = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, env=env)
    record = dict(name=name, argv=argv, started_utc=started,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  returncode=process.returncode, log=log.name)
    receipt.write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)
    print(log.read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
    results.append(record)
(OUTPUT / 'summary.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
if any(record['returncode'] == 0 for record in results):
    raise SystemExit('At least one script unexpectedly succeeded; inspect evidence.')
