import datetime
import json
import os
from pathlib import Path
import re
import subprocess

output = Path(__file__).resolve().parent
source = output.parents[2]
cmake = Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
compiler_file, = (output.parent / 'native' / 'CMakeFiles').glob('*/CMakeCXXCompiler.cmake')
compiler = re.search(r'set\(CMAKE_CXX_COMPILER "([^"]+)"\)', compiler_file.read_text()).group(1)
argv = [str(cmake), '-DSOURCE=' + source.as_posix(),
        '-DBINARY=' + (output / 'wrapper-before').as_posix(),
        '-DGENERATOR=Visual Studio 17 2022', '-DCOMPILER=' + compiler,
        '-P', str(output / 'check_mna_default_config_install.cmake.draft')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (output / 'wrapper-before.log').open('xb') as log:
    process = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, env=dict(os.environ))
record = dict(argv=argv, returncode=process.returncode, started_utc=started,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              log='wrapper-before.log')
(output / 'wrapper-before.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
text = (output / 'wrapper-before.log').read_text(encoding='utf-8', errors='replace')
print(json.dumps(record), flush=True)
print(text[-6000:], flush=True)
assert process.returncode != 0 and 'Invalid value used with --config' in text
