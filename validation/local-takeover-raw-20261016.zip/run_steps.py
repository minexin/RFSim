import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CMAKE = Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
CTEST = CMAKE.with_name('ctest.exe')
ENV = dict(os.environ)

def run(name, args):
    log = ROOT / (name + '.log')
    receipt = ROOT / (name + '.json')
    if log.exists() or receipt.exists():
        raise RuntimeError('Output already exists: ' + name)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START ' + name, flush=True)
    with log.open('xb') as stream:
        process = subprocess.run([str(a) for a in args], stdout=stream, stderr=subprocess.STDOUT, env=ENV)
    record = dict(name=name, argv=[str(a) for a in args], started_utc=start,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  returncode=process.returncode, log=log.name)
    receipt.write_text(json.dumps(record, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)
    if process.returncode:
        print(log.read_text(encoding='utf-8', errors='replace')[-10000:], flush=True)
        raise SystemExit(process.returncode)

mode = sys.argv[1]
if mode == 'configure':
    run('configure-sdk-host', [CMAKE, '-S', ROOT.parents[1], '-B', ROOT/'sdk-build-host', '-G', 'Visual Studio 17 2022', '-A', 'x64', '-DBUILD_TESTING=OFF', '-DRFMODEL_BUILD_C_API=OFF', '-DRFMODEL_BUILD_CLI=OFF', '-DRFMODEL_BUILD_EXAMPLES=OFF', '-DCMAKE_INSTALL_LIBDIR=lib'])
    run('install-sdk', [CMAKE, '--install', ROOT/'sdk-build-host', '--config', 'Release', '--prefix', ROOT/'sdk'])
    run('configure-native', [CMAKE, '-S', ROOT.parents[1], '-B', ROOT/'native', '-G', 'Visual Studio 17 2022', '-A', 'x64', '-DBUILD_TESTING=ON', '-DRFMODEL_BUILD_C_API=OFF', '-DRFMODEL_BUILD_CLI=OFF', '-DRFMODEL_BUILD_EXAMPLES=ON', '-DCMAKE_CXX_EXTENSIONS=OFF'])
elif mode in ('Release-fixed', 'Debug-fixed'):
    config = mode.split('-')[0]
    build = ROOT.parents[1] / ('build-1016' + config[0].lower())
    if build.exists():
        raise RuntimeError('Fresh short build directory already exists')
    run('configure-'+mode, [CMAKE, '-S', ROOT.parents[1], '-B', build, '-G', 'Visual Studio 17 2022', '-A', 'x64', '-DBUILD_TESTING=ON', '-DRFMODEL_BUILD_C_API=OFF', '-DRFMODEL_BUILD_CLI=OFF', '-DRFMODEL_BUILD_EXAMPLES=ON', '-DCMAKE_CXX_EXTENSIONS=OFF'])
    run('build-'+mode, [CMAKE, '--build', build, '--config', config, '--parallel', '2'])
    run('ctest-'+mode, [CTEST, '--test-dir', build, '-C', config, '--output-on-failure', '--parallel', '2', '--output-junit', ROOT/('ctest-'+mode+'.xml')])
elif mode in ('Release', 'Debug'):
    run('build-'+mode, [CMAKE, '--build', ROOT/'native', '--config', mode, '--parallel', '2'])
    run('ctest-'+mode, [CTEST, '--test-dir', ROOT/'native', '-C', mode, '--output-on-failure', '--parallel', '2', '--output-junit', ROOT/('ctest-'+mode+'.xml')])
else:
    raise ValueError(mode)
