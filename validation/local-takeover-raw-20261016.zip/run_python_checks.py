import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
REPO = OUT.parents[1]
env = dict(os.environ)
env.update({
    'RFMODEL_XPARAMETER_PROBE': str(OUT/'xparameter-replay-fixed/build/bin/xparameter_replay_probe.exe'),
    'RFMODEL_XPARAMETER_SDK': str(OUT/'sdk'),
    'RFMODEL_XPARAMETER_CMAKE': 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe',
    'RFMODEL_XPARAMETER_GENERATOR': 'Visual Studio 17 2022',
    'RFMODEL_XPARAMETER_CONFIG': 'Release',
    'RFMODEL_XPARAMETER_COMPILER': 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe',
})
checks = [
    ('evidence-check-after', ['-X', 'utf8=0', 'scripts/reference/check_compatibility_evidence.py', '--self-test']),
    ('evidence-encoding-regression', ['-X', 'utf8=0', 'scripts/reference/test_compatibility_evidence_encoding.py']),
    ('xparameter-contract-Release-ready', ['scripts/reference/test_xparameter_installed_replay.py']),
]
for name, args in checks:
    log = OUT/(name+'.log')
    receipt = OUT/(name+'.json')
    if log.exists() or receipt.exists():
        raise RuntimeError('Fresh outputs required')
    argv = [sys.executable] + args
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with log.open('xb') as stream:
        p = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
    row = dict(argv=argv, started_utc=started,
        finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        returncode=p.returncode, log=log.name,
        source_sha256=__import__('hashlib').sha256((REPO/args[args.index(next(a for a in args if a.endswith('.py')))]).read_bytes()).hexdigest())
    receipt.write_text(json.dumps(row, indent=2), encoding='utf-8')
    print(json.dumps(row), flush=True)
    print(log.read_text(encoding='utf-8', errors='replace'), flush=True)
    if p.returncode:
        raise SystemExit(p.returncode)
