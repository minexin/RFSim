# Included from the project root to retain target and CTest paths.
add_executable(model_conversion_adapter_test tests/models/model_conversion_adapter_test.cpp)
target_link_libraries(model_conversion_adapter_test PRIVATE RFModel::rfmodel)
add_test(NAME model_conversion_adapter_test COMMAND model_conversion_adapter_test)
add_executable(model_adapter_test tests/models/model_adapter_test.cpp)
target_link_libraries(model_adapter_test PRIVATE RFModel::rfmodel)
add_test(NAME model_adapter_test COMMAND model_adapter_test)
add_executable(tabulated_model_adapter_test tests/models/tabulated_model_adapter_test.cpp)
target_link_libraries(tabulated_model_adapter_test PRIVATE RFModel::rfmodel)
add_test(NAME tabulated_model_adapter_test COMMAND tabulated_model_adapter_test)
add_executable(coherent_stage_test tests/coherent/coherent_stage_test.cpp)
target_link_libraries(coherent_stage_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_stage_test COMMAND coherent_stage_test)
add_executable(coherent_system_test tests/coherent/coherent_system_test.cpp)
target_link_libraries(coherent_system_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_system_test COMMAND coherent_system_test)
add_executable(analysis_task_test tests/analysis/analysis_task_test.cpp)
target_link_libraries(analysis_task_test PRIVATE RFModel::rfmodel)
add_test(NAME analysis_task_test COMMAND analysis_task_test)
add_executable(conversion_simulation_test tests/conversion/conversion_simulation_test.cpp)
target_link_libraries(conversion_simulation_test PRIVATE RFModel::rfmodel)
add_test(NAME conversion_simulation_test COMMAND conversion_simulation_test)
if(RFMODEL_BUILD_C_API)
    add_executable(c_api_conversion_power_wave_test tests/api/c_api_conversion_power_wave_test.c)
    target_link_libraries(c_api_conversion_power_wave_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_conversion_power_wave_test PRIVATE m)
    endif()
    add_test(NAME c_api_conversion_power_wave_test COMMAND c_api_conversion_power_wave_test)
    add_executable(c_api_conversion_power_wave_regression_test tests/api/c_api_conversion_power_wave_regression_test.cpp)
    target_link_libraries(c_api_conversion_power_wave_regression_test PRIVATE RFModel::c_api RFModel::rfmodel)
    add_test(NAME c_api_conversion_power_wave_regression_test COMMAND c_api_conversion_power_wave_regression_test)
    add_executable(c_api_test tests/api/c_api_test.c)
    target_link_libraries(c_api_test PRIVATE RFModel::c_api)
    if(UNIX)
        # C callers using math functions must link libm explicitly on Unix.
        target_link_libraries(c_api_test PRIVATE m)
    endif()
    add_test(NAME c_api_test COMMAND c_api_test "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures/sweep.s2p"
        "${CMAKE_CURRENT_SOURCE_DIR}/examples/noisy-amplifier.s2p")
    add_executable(c_api_highorder_frequency_plan_test tests/api/c_api_highorder_frequency_plan_test.c)
    target_link_libraries(c_api_highorder_frequency_plan_test PRIVATE RFModel::c_api)
    add_test(NAME c_api_highorder_frequency_plan_test COMMAND c_api_highorder_frequency_plan_test)
    add_executable(c_api_monte_carlo_extended_test tests/api/c_api_monte_carlo_extended_test.c)
    target_link_libraries(c_api_monte_carlo_extended_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_monte_carlo_extended_test PRIVATE m)
    endif()
    add_test(NAME c_api_monte_carlo_extended_test COMMAND c_api_monte_carlo_extended_test)
    add_executable(c_api_monte_carlo_test tests/api/c_api_monte_carlo_test.c)
    target_link_libraries(c_api_monte_carlo_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_monte_carlo_test PRIVATE m)
    endif()
    add_test(NAME c_api_monte_carlo_test COMMAND c_api_monte_carlo_test)
    add_executable(c_api_optimization_test tests/api/c_api_optimization_test.c)
    target_link_libraries(c_api_optimization_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_optimization_test PRIVATE m)
    endif()
    add_test(NAME c_api_optimization_test COMMAND c_api_optimization_test)
    add_executable(c_api_power_wave_network_test tests/api/c_api_power_wave_network_test.c)
    target_link_libraries(c_api_power_wave_network_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_power_wave_network_test PRIVATE m)
    endif()
    add_test(NAME c_api_power_wave_network_test COMMAND c_api_power_wave_network_test)
    add_executable(c_api_mixed_reference_test tests/api/c_api_mixed_reference_test.c)
    target_link_libraries(c_api_mixed_reference_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(c_api_mixed_reference_test PRIVATE m)
    endif()
    add_test(NAME c_api_mixed_reference_test COMMAND c_api_mixed_reference_test)
    add_executable(c_api_frequency_plan_test tests/api/c_api_frequency_plan_test.c)
    target_link_libraries(c_api_frequency_plan_test PRIVATE RFModel::c_api)
    add_test(NAME c_api_frequency_plan_test COMMAND c_api_frequency_plan_test)
endif()
if(RFMODEL_BUILD_REFERENCE_TESTS)
    include(cmake/NativeReferenceReplay.cmake)
    include(cmake/SourceReferenceReplay.cmake)
    include(cmake/CascadeReferenceReplay.cmake)
endif()
if(RFMODEL_BUILD_CLI)
add_test(NAME cli_export COMMAND ${CMAKE_COMMAND}
    -DCLI=$<TARGET_FILE:rfmodel_cli> -DFIXTURES=${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures
    -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_cli.cmake)
endif()
add_executable(frequency_dependent_cable_test tests/models/frequency_dependent_cable_test.cpp)
target_link_libraries(frequency_dependent_cable_test PRIVATE RFModel::rfmodel)
add_test(NAME frequency_dependent_cable_test COMMAND frequency_dependent_cable_test)
add_executable(rfmodel_smoke tests/core/smoke.cpp)
target_link_libraries(rfmodel_smoke PRIVATE rfmodel)
add_executable(linear_solver_smoke tests/core/linear_solver_smoke.cpp)
target_link_libraries(linear_solver_smoke PRIVATE rfmodel)
add_test(NAME rfmodel_smoke COMMAND rfmodel_smoke)
add_test(NAME linear_solver_smoke COMMAND linear_solver_smoke)
add_executable(touchstone_smoke tests/io/touchstone_smoke.cpp)
target_link_libraries(touchstone_smoke PRIVATE rfmodel)
add_test(NAME touchstone_smoke COMMAND touchstone_smoke "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures")

# Bounded native Touchstone 2.0 import and scalar-interface safeguards.
add_executable(touchstone_two_test tests/io/touchstone_two_test.cpp)
target_link_libraries(touchstone_two_test PRIVATE rfmodel)
add_test(NAME touchstone_two_test COMMAND touchstone_two_test)
if(RFMODEL_BUILD_C_API)
    add_executable(touchstone_two_c_test tests/api/touchstone_two_c_test.c)
    target_link_libraries(touchstone_two_c_test PRIVATE RFModel::c_api)
    if(UNIX)
        target_link_libraries(touchstone_two_c_test PRIVATE m)
    endif()
    add_test(NAME touchstone_two_c_test COMMAND touchstone_two_c_test)
endif()
if(RFMODEL_BUILD_CLI)
    add_test(NAME touchstone_two_cli_test COMMAND ${CMAKE_COMMAND}
        -DCLI=$<TARGET_FILE:rfmodel_cli> -P "${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/touchstone_two_cli.cmake")
endif()

add_executable(touchstone_validation tests/io/touchstone_validation.cpp)
target_link_libraries(touchstone_validation PRIVATE rfmodel)
add_test(NAME touchstone_validation COMMAND touchstone_validation "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures")
add_executable(network_test tests/linear/network_test.cpp)
target_link_libraries(network_test PRIVATE rfmodel)
add_test(NAME network_test COMMAND network_test)
add_executable(sweep_test tests/linear/sweep_test.cpp)
target_link_libraries(sweep_test PRIVATE rfmodel)
add_test(NAME sweep_test COMMAND sweep_test "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures")
add_executable(measurements_test tests/analysis/measurements_test.cpp)
target_link_libraries(measurements_test PRIVATE rfmodel)
add_test(NAME measurements_test COMMAND measurements_test)
add_executable(noise_test tests/noise/noise_test.cpp)
target_link_libraries(noise_test PRIVATE rfmodel)
add_test(NAME noise_test COMMAND noise_test)
add_executable(external_s_test tests/linear/external_s_test.cpp)
target_link_libraries(external_s_test PRIVATE rfmodel)
add_test(NAME external_s_test COMMAND external_s_test)
add_executable(linear_analysis_test tests/linear/linear_analysis_test.cpp)
target_link_libraries(linear_analysis_test PRIVATE rfmodel)
add_test(NAME linear_analysis_test COMMAND linear_analysis_test)
add_executable(tabulated_model_test tests/io/tabulated_model_test.cpp)
target_link_libraries(tabulated_model_test PRIVATE rfmodel)
add_test(NAME tabulated_model_test COMMAND tabulated_model_test "${CMAKE_CURRENT_SOURCE_DIR}/tests/fixtures")
add_executable(ideal_devices_test tests/models/ideal_devices_test.cpp)
target_link_libraries(ideal_devices_test PRIVATE rfmodel)
add_test(NAME ideal_devices_test COMMAND ideal_devices_test)
add_executable(transmission_line_test tests/models/transmission_line_test.cpp)
target_link_libraries(transmission_line_test PRIVATE rfmodel)
add_test(NAME transmission_line_test COMMAND transmission_line_test)
add_executable(rlgc_transmission_line_test tests/models/rlgc_transmission_line_test.cpp)
target_link_libraries(rlgc_transmission_line_test PRIVATE rfmodel)
add_test(NAME rlgc_transmission_line_test COMMAND rlgc_transmission_line_test)
add_executable(multiport_devices_test tests/models/multiport_devices_test.cpp)
target_link_libraries(multiport_devices_test PRIVATE rfmodel)
add_test(NAME multiport_devices_test COMMAND multiport_devices_test)
add_executable(impedance_test tests/analysis/impedance_test.cpp)
target_link_libraries(impedance_test PRIVATE rfmodel)
add_test(NAME impedance_test COMMAND impedance_test)
add_executable(group_delay_test tests/analysis/group_delay_test.cpp)
target_link_libraries(group_delay_test PRIVATE rfmodel)
add_test(NAME group_delay_test COMMAND group_delay_test)
add_executable(network_parameters_test tests/core/network_parameters_test.cpp)
target_link_libraries(network_parameters_test PRIVATE rfmodel)
add_test(NAME network_parameters_test COMMAND network_parameters_test)
add_executable(renormalization_test tests/core/renormalization_test.cpp)
target_link_libraries(renormalization_test PRIVATE rfmodel)
add_test(NAME renormalization_test COMMAND renormalization_test)
add_executable(lumped_model_test tests/models/lumped_model_test.cpp)
target_link_libraries(lumped_model_test PRIVATE rfmodel)
add_test(NAME lumped_model_test COMMAND lumped_model_test)
add_executable(rlc_model_test tests/models/rlc_model_test.cpp)
target_link_libraries(rlc_model_test PRIVATE rfmodel)
add_test(NAME rlc_model_test COMMAND rlc_model_test)
add_executable(noise_matrix_test tests/noise/noise_matrix_test.cpp)
target_link_libraries(noise_matrix_test PRIVATE rfmodel)
add_test(NAME noise_matrix_test COMMAND noise_matrix_test)
add_executable(noise_renormalization_test tests/noise/noise_renormalization_test.cpp)
target_link_libraries(noise_renormalization_test PRIVATE rfmodel)
add_test(NAME noise_renormalization_test COMMAND noise_renormalization_test)
add_executable(network_noise_test tests/noise/network_noise_test.cpp)
target_link_libraries(network_noise_test PRIVATE rfmodel)
add_test(NAME network_noise_test COMMAND network_noise_test)
add_executable(linear_noise_test tests/noise/linear_noise_test.cpp)
target_link_libraries(linear_noise_test PRIVATE rfmodel)
add_test(NAME linear_noise_test COMMAND linear_noise_test)
add_executable(noise_figure_test tests/noise/noise_figure_test.cpp)
target_link_libraries(noise_figure_test PRIVATE rfmodel)
add_test(NAME noise_figure_test COMMAND noise_figure_test)
add_executable(noise_parameters_test tests/noise/noise_parameters_test.cpp)
target_link_libraries(noise_parameters_test PRIVATE rfmodel)
add_test(NAME noise_parameters_test COMMAND noise_parameters_test)
add_executable(noise_import_test tests/io/noise_import_test.cpp)
target_link_libraries(noise_import_test PRIVATE rfmodel)
add_test(NAME noise_import_test COMMAND noise_import_test)
add_executable(tabulated_noise_test tests/io/tabulated_noise_test.cpp)
target_link_libraries(tabulated_noise_test PRIVATE rfmodel)
add_test(NAME tabulated_noise_test COMMAND tabulated_noise_test)
add_executable(touchstone_noise_test tests/io/touchstone_noise_test.cpp)
target_link_libraries(touchstone_noise_test PRIVATE rfmodel)
add_test(NAME touchstone_noise_test COMMAND touchstone_noise_test)
add_executable(nonlinear_spectrum_test tests/nonlinear/nonlinear_spectrum_test.cpp)
target_link_libraries(nonlinear_spectrum_test PRIVATE rfmodel)
add_test(NAME nonlinear_spectrum_test COMMAND nonlinear_spectrum_test)
add_executable(power_wave_reference_test tests/core/power_wave_reference_test.cpp)
target_link_libraries(power_wave_reference_test PRIVATE rfmodel)
add_test(NAME power_wave_reference_test COMMAND power_wave_reference_test)
add_executable(intermod_levels_test tests/nonlinear/intermod_levels_test.cpp)
target_link_libraries(intermod_levels_test PRIVATE rfmodel)
add_test(NAME intermod_levels_test COMMAND intermod_levels_test)
add_executable(polynomial_intercepts_test tests/nonlinear/polynomial_intercepts_test.cpp)
target_link_libraries(polynomial_intercepts_test PRIVATE rfmodel)
add_test(NAME polynomial_intercepts_test COMMAND polynomial_intercepts_test)
add_executable(polynomial_amplifier_test tests/nonlinear/polynomial_amplifier_test.cpp)
target_link_libraries(polynomial_amplifier_test PRIVATE rfmodel)
add_test(NAME polynomial_amplifier_test COMMAND polynomial_amplifier_test)
add_executable(fundamental_compression_test tests/nonlinear/fundamental_compression_test.cpp)
target_link_libraries(fundamental_compression_test PRIVATE rfmodel)
add_test(NAME fundamental_compression_test COMMAND fundamental_compression_test)
add_executable(saturating_fundamental_test tests/nonlinear/saturating_fundamental_test.cpp)
target_link_libraries(saturating_fundamental_test PRIVATE rfmodel)
add_test(NAME saturating_fundamental_test COMMAND saturating_fundamental_test)
add_executable(single_tone_amplifier_test tests/nonlinear/single_tone_amplifier_test.cpp)
target_link_libraries(single_tone_amplifier_test PRIVATE rfmodel)
add_test(NAME single_tone_amplifier_test COMMAND single_tone_amplifier_test)
add_executable(multitone_amplifier_test tests/nonlinear/multitone_amplifier_test.cpp)
target_link_libraries(multitone_amplifier_test PRIVATE rfmodel)
add_test(NAME multitone_amplifier_test COMMAND multitone_amplifier_test)
add_executable(origin_expression_test tests/coherent/origin_expression_test.cpp)
target_link_libraries(origin_expression_test PRIVATE rfmodel)
add_test(NAME origin_expression_test COMMAND origin_expression_test)

add_executable(mixing_origin_test tests/coherent/mixing_origin_test.cpp)
target_link_libraries(mixing_origin_test PRIVATE rfmodel)
add_test(NAME mixing_origin_test COMMAND mixing_origin_test)
add_executable(coherent_highorder_amplifier_test tests/coherent/coherent_highorder_amplifier_test.cpp)
target_link_libraries(coherent_highorder_amplifier_test PRIVATE rfmodel)
add_test(NAME coherent_highorder_amplifier_test COMMAND coherent_highorder_amplifier_test)
add_executable(coherent_pipeline_test tests/coherent/coherent_pipeline.cpp)
target_link_libraries(coherent_pipeline_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_pipeline_test COMMAND coherent_pipeline_test)
add_executable(coherent_pipeline_limits_test tests/coherent/coherent_pipeline_limits_test.cpp)
target_link_libraries(coherent_pipeline_limits_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_pipeline_limits_test COMMAND coherent_pipeline_limits_test)
add_executable(coherent_pipeline_amplifier_test tests/coherent/coherent_pipeline_amplifier_test.cpp)
target_link_libraries(coherent_pipeline_amplifier_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_pipeline_amplifier_test COMMAND coherent_pipeline_amplifier_test)
add_executable(coherent_pipeline_amplifier_limits_test tests/coherent/coherent_pipeline_amplifier_limits_test.cpp)
target_link_libraries(coherent_pipeline_amplifier_limits_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_pipeline_amplifier_limits_test COMMAND coherent_pipeline_amplifier_limits_test)
add_executable(coherent_pipeline_allocation_test tests/coherent/coherent_pipeline_allocation_test.cpp)
target_link_libraries(coherent_pipeline_allocation_test PRIVATE RFModel::rfmodel)
add_test(NAME coherent_pipeline_allocation_test COMMAND coherent_pipeline_allocation_test)
set_tests_properties(coherent_pipeline_amplifier_limits_test coherent_pipeline_allocation_test
    PROPERTIES TIMEOUT 300)
# MSVC checked iterators allocate proxies inside noexcept vector constructors.
# Keep all ordinary Debug tests checked, and run every allocation-failure sweep
# separately with the normal throwing-allocation contract. This single-TU target
# links only the header-only SDK, so no STL ABI crosses a compiled-library boundary.
if(MSVC)
    target_compile_definitions(coherent_pipeline_allocation_test PRIVATE _ITERATOR_DEBUG_LEVEL=0)
endif()
# Exception-safety tests must not rely on optional named-return-value elision.
foreach(target coherent_pipeline_amplifier_limits_test coherent_pipeline_allocation_test)
    if(MSVC AND MSVC_VERSION GREATER_EQUAL 1934)
        target_compile_options(${target} PRIVATE /Zc:nrvo-)
    elseif(CMAKE_CXX_COMPILER_ID MATCHES "^(GNU|Clang|AppleClang)$")
        target_compile_options(${target} PRIVATE -fno-elide-constructors)
    endif()
endforeach()
add_executable(coherent_polynomial_test tests/coherent/coherent_polynomial_test.cpp)
target_link_libraries(coherent_polynomial_test PRIVATE rfmodel)
add_test(NAME coherent_polynomial_test COMMAND coherent_polynomial_test)
add_executable(amplifier_operating_point_test tests/nonlinear/amplifier_operating_point_test.cpp)
target_link_libraries(amplifier_operating_point_test PRIVATE rfmodel)
add_test(NAME amplifier_operating_point_test COMMAND amplifier_operating_point_test)

add_executable(coherent_amplifier_test tests/coherent/coherent_amplifier_test.cpp)
target_link_libraries(coherent_amplifier_test PRIVATE rfmodel)
add_test(NAME coherent_amplifier_test COMMAND coherent_amplifier_test)
add_executable(coherent_compression_test tests/coherent/coherent_compression_test.cpp)
target_link_libraries(coherent_compression_test PRIVATE rfmodel)
add_test(NAME coherent_compression_test COMMAND coherent_compression_test)

add_executable(coherent_mixer_test tests/coherent/coherent_mixer_test.cpp)
target_link_libraries(coherent_mixer_test PRIVATE rfmodel)
add_test(NAME coherent_mixer_test COMMAND coherent_mixer_test)
add_executable(source_coherence_test tests/coherent/source_coherence_test.cpp)
target_link_libraries(source_coherence_test PRIVATE rfmodel)
add_test(NAME source_coherence_test COMMAND source_coherence_test)
add_executable(coherent_network_test tests/coherent/coherent_network_test.cpp)
target_link_libraries(coherent_network_test PRIVATE rfmodel)
add_test(NAME coherent_network_test COMMAND coherent_network_test)
add_executable(coherence_test tests/coherent/coherence_test.cpp)
target_link_libraries(coherence_test PRIVATE rfmodel)
add_test(NAME coherence_test COMMAND coherence_test)
add_executable(term_propagation_test tests/coherent/term_propagation_test.cpp)
target_link_libraries(term_propagation_test PRIVATE rfmodel)
add_test(NAME term_propagation_test COMMAND term_propagation_test)
add_executable(ideal_mixer_test tests/nonlinear/ideal_mixer_test.cpp)
target_link_libraries(ideal_mixer_test PRIVATE rfmodel)
add_test(NAME ideal_mixer_test COMMAND ideal_mixer_test)
add_executable(spectrum_analysis_test tests/analysis/spectrum_analysis_test.cpp)
target_link_libraries(spectrum_analysis_test PRIVATE rfmodel)
add_test(NAME spectrum_analysis_test COMMAND spectrum_analysis_test)
add_executable(amplifier_model_test tests/nonlinear/amplifier_model_test.cpp)
target_link_libraries(amplifier_model_test PRIVATE rfmodel)
add_test(NAME amplifier_model_test COMMAND amplifier_model_test)
add_executable(power_gain_test tests/analysis/power_gain_test.cpp)
target_link_libraries(power_gain_test PRIVATE rfmodel)
add_test(NAME power_gain_test COMMAND power_gain_test)
add_executable(linear_path_test tests/linear/linear_path_test.cpp)
target_link_libraries(linear_path_test PRIVATE rfmodel)
add_test(NAME linear_path_test COMMAND linear_path_test)
add_executable(reference_attenuator tests/reference/reference_attenuator.cpp)
add_executable(linear_path_noise_test tests/noise/linear_path_noise_test.cpp)
target_link_libraries(linear_path_noise_test PRIVATE rfmodel)
add_test(NAME linear_path_noise_test COMMAND linear_path_noise_test)
add_executable(loaded_noise_test tests/noise/loaded_noise_test.cpp)
target_link_libraries(loaded_noise_test PRIVATE rfmodel)
add_test(NAME loaded_noise_test COMMAND loaded_noise_test)
target_link_libraries(reference_attenuator PRIVATE rfmodel)
add_executable(reference_antenna tests/reference/reference_antenna.cpp)
target_link_libraries(reference_antenna PRIVATE rfmodel)
add_test(NAME reference_antenna_analytic COMMAND reference_antenna)
add_test(NAME reference_antenna_source_density COMMAND reference_antenna 6.903251499999993e-22)

add_executable(power_wave_noise_test tests/noise/power_wave_noise_test.cpp)
target_link_libraries(power_wave_noise_test PRIVATE rfmodel)
add_test(NAME power_wave_noise_test COMMAND power_wave_noise_test)

add_executable(butterworth_filter_test tests/models/butterworth_filter_test.cpp)
target_link_libraries(butterworth_filter_test PRIVATE rfmodel)
add_test(NAME butterworth_filter_test COMMAND butterworth_filter_test)

add_executable(chebyshev_filter_test tests/models/chebyshev_filter_test.cpp)
target_link_libraries(chebyshev_filter_test PRIVATE rfmodel)
add_test(NAME chebyshev_filter_test COMMAND chebyshev_filter_test)

add_executable(conversion_power_wave_test tests/conversion/conversion_power_wave_test.cpp)
target_link_libraries(conversion_power_wave_test PRIVATE rfmodel)
add_test(NAME conversion_power_wave_test COMMAND conversion_power_wave_test)

add_executable(frequency_conversion_test tests/conversion/frequency_conversion_test.cpp)
target_link_libraries(frequency_conversion_test PRIVATE rfmodel)
add_test(NAME frequency_conversion_test COMMAND frequency_conversion_test)

add_executable(conversion_network_test tests/conversion/conversion_network_test.cpp)
target_link_libraries(conversion_network_test PRIVATE rfmodel)
add_test(NAME conversion_network_test COMMAND conversion_network_test)

add_executable(conversion_loaded_noise_test tests/conversion/conversion_loaded_noise_test.cpp)
target_link_libraries(conversion_loaded_noise_test PRIVATE rfmodel)
add_test(NAME conversion_loaded_noise_test COMMAND conversion_loaded_noise_test)

add_executable(channel_noise_test tests/noise/channel_noise_test.cpp)
target_link_libraries(channel_noise_test PRIVATE rfmodel)
add_test(NAME channel_noise_test COMMAND channel_noise_test)

add_executable(phase_noise_test tests/noise/phase_noise_test.cpp)
target_link_libraries(phase_noise_test PRIVATE rfmodel)
add_test(NAME phase_noise_test COMMAND phase_noise_test)

add_executable(shared_phase_noise_test tests/noise/shared_phase_noise_test.cpp)
target_link_libraries(shared_phase_noise_test PRIVATE rfmodel)
add_test(NAME shared_phase_noise_test COMMAND shared_phase_noise_test)

add_executable(mixer_linearization_test tests/conversion/mixer_linearization_test.cpp)
target_link_libraries(mixer_linearization_test PRIVATE rfmodel)
add_test(NAME mixer_linearization_test COMMAND mixer_linearization_test)

add_executable(affine_conversion_test tests/conversion/affine_conversion_test.cpp)
target_link_libraries(affine_conversion_test PRIVATE rfmodel)
add_test(NAME affine_conversion_test COMMAND affine_conversion_test)

add_executable(conversion_operating_point_power_wave_test tests/conversion/conversion_operating_point_power_wave_test.cpp)
target_link_libraries(conversion_operating_point_power_wave_test PRIVATE rfmodel)
add_test(NAME conversion_operating_point_power_wave_test COMMAND conversion_operating_point_power_wave_test)

add_executable(conversion_operating_point_power_wave_contract_test tests/conversion/conversion_operating_point_power_wave_contract_test.cpp)
target_link_libraries(conversion_operating_point_power_wave_contract_test PRIVATE rfmodel)
add_test(NAME conversion_operating_point_power_wave_contract_test COMMAND conversion_operating_point_power_wave_contract_test)

add_executable(conversion_operating_noise_test tests/conversion/conversion_operating_noise_test.cpp)
target_link_libraries(conversion_operating_noise_test PRIVATE rfmodel)
add_test(NAME conversion_operating_noise_test COMMAND conversion_operating_noise_test)

add_executable(conversion_operating_point_test tests/conversion/conversion_operating_point_test.cpp)
target_link_libraries(conversion_operating_point_test PRIVATE rfmodel)
add_test(NAME conversion_operating_point_test COMMAND conversion_operating_point_test)

add_executable(amplifier_linearization_test tests/conversion/amplifier_linearization_test.cpp)
target_link_libraries(amplifier_linearization_test PRIVATE rfmodel)
add_test(NAME amplifier_linearization_test COMMAND amplifier_linearization_test)

add_executable(polynomial_linearization_test tests/conversion/polynomial_linearization_test.cpp)
target_link_libraries(polynomial_linearization_test PRIVATE rfmodel)
add_test(NAME polynomial_linearization_test COMMAND polynomial_linearization_test)

add_executable(parameter_solver_residual_test tests/core/parameter_solver_residual_test.cpp)
target_link_libraries(parameter_solver_residual_test PRIVATE rfmodel)
add_test(NAME parameter_solver_residual_test COMMAND parameter_solver_residual_test)

add_executable(highorder_linearization_test tests/conversion/highorder_linearization_test.cpp)
target_link_libraries(highorder_linearization_test PRIVATE rfmodel)
add_test(NAME highorder_linearization_test COMMAND highorder_linearization_test)

add_executable(am_pm_test tests/nonlinear/am_pm_test.cpp)
target_link_libraries(am_pm_test PRIVATE rfmodel)
add_test(NAME am_pm_test COMMAND am_pm_test)

add_executable(conversion_frequency_plan_test tests/conversion/conversion_frequency_plan_test.cpp)
target_link_libraries(conversion_frequency_plan_test PRIVATE rfmodel)
add_test(NAME conversion_frequency_plan_test COMMAND conversion_frequency_plan_test)

add_executable(highorder_frequency_plan_test tests/conversion/highorder_frequency_plan_test.cpp)
target_link_libraries(highorder_frequency_plan_test PRIVATE rfmodel)
add_test(NAME highorder_frequency_plan_test COMMAND highorder_frequency_plan_test)

add_executable(power_wave_network_test tests/linear/power_wave_network_test.cpp)
target_link_libraries(power_wave_network_test PRIVATE rfmodel)
add_test(NAME power_wave_network_test COMMAND power_wave_network_test)

add_executable(mixed_reference_network_test tests/linear/mixed_reference_network_test.cpp)
target_link_libraries(mixed_reference_network_test PRIVATE rfmodel)
add_test(NAME mixed_reference_network_test COMMAND mixed_reference_network_test)

add_executable(optimization_test tests/analysis/optimization_test.cpp)
target_link_libraries(optimization_test PRIVATE rfmodel)
add_test(NAME optimization_test COMMAND optimization_test)

add_executable(monte_carlo_test tests/analysis/monte_carlo_test.cpp)
target_link_libraries(monte_carlo_test PRIVATE rfmodel)
add_test(NAME monte_carlo_test COMMAND monte_carlo_test)

add_executable(monte_carlo_joint_test tests/analysis/monte_carlo_joint_test.cpp)
target_link_libraries(monte_carlo_joint_test PRIVATE rfmodel)
add_test(NAME monte_carlo_joint_test COMMAND monte_carlo_joint_test)

add_executable(conversion_mixer_physics_test tests/conversion/conversion_mixer_physics_test.cpp)
target_link_libraries(conversion_mixer_physics_test PRIVATE RFModel::rfmodel)
add_test(NAME conversion_mixer_physics_test COMMAND conversion_mixer_physics_test)
add_test(NAME sdk_configuration_test COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/sdk-configuration-test
    -DGENERATOR=${CMAKE_GENERATOR}
    -DCOMPILER=${CMAKE_CXX_COMPILER}
    -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_sdk_configuration.cmake)

add_executable(highorder_model_adapter_test tests/models/highorder_model_adapter_test.cpp)
target_link_libraries(highorder_model_adapter_test PRIVATE RFModel::rfmodel)
add_test(NAME highorder_model_adapter_test COMMAND highorder_model_adapter_test)

add_executable(bilinear_mixer_adapter_test tests/models/bilinear_mixer_adapter_test.cpp)
target_link_libraries(bilinear_mixer_adapter_test PRIVATE RFModel::rfmodel)
add_test(NAME bilinear_mixer_adapter_test COMMAND bilinear_mixer_adapter_test)

add_executable(noise_factor_test tests/noise/noise_factor_test.cpp)
target_link_libraries(noise_factor_test PRIVATE RFModel::rfmodel)
add_test(NAME noise_factor_test COMMAND noise_factor_test)
add_executable(noise_independent_blocks_test tests/noise/noise_independent_blocks_test.cpp)
target_link_libraries(noise_independent_blocks_test PRIVATE RFModel::rfmodel)
add_test(NAME noise_independent_blocks_test COMMAND noise_independent_blocks_test)
add_executable(noise_independent_blocks_integration_test tests/noise/noise_independent_blocks_integration_test.cpp)
target_link_libraries(noise_independent_blocks_integration_test PRIVATE RFModel::rfmodel)
add_test(NAME noise_independent_blocks_integration_test COMMAND noise_independent_blocks_integration_test)
add_executable(noise_independent_blocks_callers_test tests/noise/noise_independent_blocks_callers_test.cpp)
target_link_libraries(noise_independent_blocks_callers_test PRIVATE RFModel::rfmodel)
add_test(NAME noise_independent_blocks_callers_test COMMAND noise_independent_blocks_callers_test)
add_executable(noise_factor_integration_test tests/noise/noise_factor_integration_test.cpp)
target_link_libraries(noise_factor_integration_test PRIVATE RFModel::rfmodel)
add_test(NAME noise_factor_integration_test COMMAND noise_factor_integration_test)

add_executable(phd_coefficient_slice_test tests/nonlinear/phd_coefficient_slice_test.cpp)
target_link_libraries(phd_coefficient_slice_test PRIVATE RFModel::rfmodel)
add_test(NAME phd_coefficient_slice_test COMMAND phd_coefficient_slice_test)

if(NOT RFMODEL_BUILD_C_API)
    add_test(NAME sdk_archive_test COMMAND ${CMAKE_COMMAND}
        -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
        -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/sdk-archive-test
        -DGENERATOR=${CMAKE_GENERATOR}
        -DCOMPILER=${CMAKE_CXX_COMPILER}
        -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_sdk_archive.cmake)
endif()

add_executable(basic_api_contract_test tests/core/basic_api_contract_test.cpp)
target_link_libraries(basic_api_contract_test PRIVATE RFModel::rfmodel)
add_test(NAME basic_api_contract_test COMMAND basic_api_contract_test)

add_executable(parameter_vector_solver_test tests/core/parameter_vector_solver_test.cpp)
target_link_libraries(parameter_vector_solver_test PRIVATE RFModel::rfmodel)
add_test(NAME parameter_vector_solver_test COMMAND parameter_vector_solver_test)
add_executable(conversion_wave_solve_test tests/conversion/conversion_wave_solve_test.cpp)
target_link_libraries(conversion_wave_solve_test PRIVATE RFModel::rfmodel)
add_test(NAME conversion_wave_solve_test COMMAND conversion_wave_solve_test)

add_executable(touchstone_writer_test tests/io/touchstone_writer_test.cpp)
target_link_libraries(touchstone_writer_test PRIVATE RFModel::rfmodel)
add_test(NAME touchstone_writer_test COMMAND touchstone_writer_test)
add_test(NAME touchstone_writer_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/touchstone-writer-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_touchstone_writer_install.cmake)
set_tests_properties(touchstone_writer_installed PROPERTIES TIMEOUT 300)

add_executable(external_s_factorization_test tests/linear/external_s_factorization_test.cpp)
target_link_libraries(external_s_factorization_test PRIVATE RFModel::rfmodel)
add_test(NAME external_s_factorization_test COMMAND external_s_factorization_test)

add_executable(phd_fixed_pump_network_test tests/nonlinear/phd_fixed_pump_network_test.cpp)
target_link_libraries(phd_fixed_pump_network_test PRIVATE RFModel::rfmodel)
add_test(NAME phd_fixed_pump_network_test COMMAND phd_fixed_pump_network_test)

add_executable(tabulated_amplifier_test tests/conversion/tabulated_amplifier_test.cpp)
target_link_libraries(tabulated_amplifier_test PRIVATE RFModel::rfmodel)
add_test(NAME tabulated_amplifier_test COMMAND tabulated_amplifier_test)
add_test(NAME tabulated_amplifier_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/tabulated-amplifier-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_tabulated_amplifier_install.cmake)
set_tests_properties(tabulated_amplifier_installed PROPERTIES TIMEOUT 300)

add_executable(dc_operating_point_test tests/nonlinear/dc_operating_point_test.cpp)
target_link_libraries(dc_operating_point_test PRIVATE RFModel::rfmodel)
add_test(NAME dc_operating_point_test COMMAND dc_operating_point_test)
add_executable(frozen_small_signal_test tests/linear/frozen_small_signal_test.cpp)
target_link_libraries(frozen_small_signal_test PRIVATE RFModel::rfmodel)
add_test(NAME frozen_small_signal_test COMMAND frozen_small_signal_test)
add_executable(frozen_noise_test tests/linear/frozen_noise_test.cpp)
target_link_libraries(frozen_noise_test PRIVATE RFModel::rfmodel)
add_test(NAME frozen_noise_test COMMAND frozen_noise_test)
add_test(NAME dc_bias_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/dc-bias-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_dc_bias_install.cmake)
set_tests_properties(dc_bias_installed PROPERTIES TIMEOUT 300)

# Autonomous bounded raw X-parameter format contract (no vendor runtime).
add_executable(xparameter_data_test tests/io/xparameter_data_test.cpp)
target_link_libraries(xparameter_data_test PRIVATE RFModel::rfmodel)
add_test(NAME xparameter_data_test COMMAND xparameter_data_test)

add_executable(xparameter_catalog_test tests/io/xparameter_catalog_test.cpp)
target_link_libraries(xparameter_catalog_test PRIVATE RFModel::rfmodel)
add_test(NAME xparameter_catalog_test COMMAND xparameter_catalog_test)

add_executable(locked_pi_pll_test tests/noise/locked_pi_pll_test.cpp)
target_link_libraries(locked_pi_pll_test PRIVATE rfmodel)
add_test(NAME locked_pi_pll_test COMMAND locked_pi_pll_test)

add_executable(phase_response_test tests/noise/phase_response_test.cpp)
target_link_libraries(phase_response_test PRIVATE RFModel::rfmodel)
add_test(NAME phase_response_test COMMAND phase_response_test)

add_executable(phase_jitter_test tests/noise/phase_jitter_test.cpp)
target_link_libraries(phase_jitter_test PRIVATE rfmodel)
add_test(NAME phase_jitter_test COMMAND phase_jitter_test)

# End-to-end PLL/noise/jitter host example, compiled only against an installed SDK.
add_test(NAME pll_phase_jitter_sdk_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/pll-phase-jitter-sdk-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_pll_phase_jitter_install.cmake)
set_tests_properties(pll_phase_jitter_sdk_installed PROPERTIES TIMEOUT 300)

# End-to-end Frozen DC adapter host example, compiled only against an installed SDK.
add_test(NAME frozen_adapter_sdk_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/frozen-adapter-sdk-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_frozen_adapter_install.cmake)
set_tests_properties(frozen_adapter_sdk_installed PROPERTIES TIMEOUT 300)

# Independent owning bounded linear MNA; distinct from the nonlinear DC solver.
add_executable(linear_mna_test tests/mna/linear_network_test.cpp)
target_link_libraries(linear_mna_test PRIVATE RFModel::rfmodel)
add_test(NAME linear_mna_test COMMAND linear_mna_test)
add_test(NAME linear_mna_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/linear-mna-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_linear_mna_install.cmake)
set_tests_properties(linear_mna_installed PROPERTIES TIMEOUT 300)

add_executable(mna_power_wave_s_test tests/mna/test_power_wave_s.cpp)
target_link_libraries(mna_power_wave_s_test PRIVATE RFModel::rfmodel)
add_test(NAME mna_power_wave_s_test COMMAND mna_power_wave_s_test)
add_test(NAME mna_power_wave_s_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/mna-power-wave-s-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_mna_power_wave_s_install.cmake)
set_tests_properties(mna_power_wave_s_installed PROPERTIES TIMEOUT 300)

add_test(NAME mna_installed_default_config COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/mna-installed-default-config
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_mna_default_config_install.cmake)
set_tests_properties(mna_installed_default_config PROPERTIES TIMEOUT 300)

add_executable(mna_factorization_test tests/mna/factorization_test.cpp)
target_link_libraries(mna_factorization_test PRIVATE RFModel::rfmodel)
add_test(NAME mna_factorization_test COMMAND mna_factorization_test)

# Real MNA/thermal-noise host workflow; both relocated SDK modes, two C++17 TUs.
add_test(NAME mna_noise_sdk_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/mna-noise-sdk-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_mna_noise_install.cmake)
set_tests_properties(mna_noise_sdk_installed PROPERTIES TIMEOUT 300)

# Same named behavioral instances/wiring, external S and loaded port reports.
add_test(NAME behavioral_system_sdk_installed COMMAND ${CMAKE_COMMAND}
    -DSOURCE=${CMAKE_CURRENT_SOURCE_DIR}
    -DBINARY=${CMAKE_CURRENT_BINARY_DIR}/behavioral-system-sdk-installed
    -DGENERATOR=${CMAKE_GENERATOR} -DCOMPILER=${CMAKE_CXX_COMPILER}
    -DCONFIG=$<CONFIG> -P ${CMAKE_CURRENT_SOURCE_DIR}/tests/cmake/check_behavioral_system_install.cmake)
set_tests_properties(behavioral_system_sdk_installed PROPERTIES TIMEOUT 300)
