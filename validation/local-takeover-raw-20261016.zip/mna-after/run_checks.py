import datetime
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent
CMAKE = Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe')
CTEST = CMAKE.with_name('ctest.exe')
ENV = dict(os.environ)
assert sum(key.upper() == 'PATH' for key in ENV) <= 1
records = []

def run(name, args):
    argv = [str(arg) for arg in args]
    log = ROOT / (name + '.log')
    receipt = ROOT / (name + '.json')
    if log.exists() or receipt.exists():
        raise RuntimeError('Refusing to overwrite evidence: ' + name)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START ' + name, flush=True)
    with log.open('xb') as stream:
        process = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, env=ENV)
    record = dict(name=name, argv=argv, started_utc=started,
                  finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  returncode=process.returncode, log=log.name)
    receipt.write_text(json.dumps(record, indent=2), encoding='utf-8')
    records.append(record)
    (ROOT / 'summary.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
    print(json.dumps(record), flush=True)
    print(log.read_text(encoding='utf-8', errors='replace')[-7000:], flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)

native = ROOT / 'native'
run('configure', [CMAKE, '-S', SOURCE, '-B', native, '-G', 'Visual Studio 17 2022',
                  '-A', 'x64', '-DBUILD_TESTING=ON', '-DRFMODEL_BUILD_C_API=OFF',
                  '-DRFMODEL_BUILD_CLI=OFF', '-DRFMODEL_BUILD_EXAMPLES=OFF',
                  '-DCMAKE_CXX_EXTENSIONS=OFF'])
base_tests = 'linear_mna_test|mna_power_wave_s_test|mna_factorization_test|linear_mna_installed|mna_power_wave_s_installed'
for config in ('Release', 'Debug'):
    run('build-' + config, [CMAKE, '--build', native, '--config', config, '--parallel', '2',
                            '--target', 'linear_mna_test', 'mna_power_wave_s_test', 'mna_factorization_test'])
    regex = '^(' + base_tests + ('|mna_installed_default_config' if config == 'Release' else '') + ')$'
    run('ctest-' + config, [CTEST, '--test-dir', native, '-C', config, '-R', regex,
                            '--output-on-failure', '--parallel', '1',
                            '--output-junit', ROOT / ('ctest-' + config + '.xml')])
