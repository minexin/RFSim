import hashlib
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
source = root.parent
before = source / 'build-reference/local-takeover-20261016/mna-empty-config-before'
shutil.copy2(root / 'native/Testing/Temporary/LastTest.log', root / 'ctest-Debug-detailed.log')
files = ('tests/cmake/check_linear_mna_install.cmake',
         'tests/cmake/check_mna_power_wave_s_install.cmake',
         'tests/cmake/check_mna_default_config_install.cmake',
         'cmake/RFModelTests.cmake')
record = {'source_sha256': {path: hashlib.sha256((source / path).read_bytes()).hexdigest()
                            for path in files},
          'before': json.loads((before / 'summary.json').read_text()),
          'before_wrapper': json.loads((before / 'wrapper-before.json').read_text()),
          'after': json.loads((root / 'summary.json').read_text()),
          'ctest': {config: ET.parse(root / ('ctest-' + config + '.xml')).getroot().attrib
                    for config in ('Release', 'Debug')},
          'detailed_logs': ['ctest-Release-detailed.log', 'ctest-Debug-detailed.log']}
assert all(item['returncode'] == 1 for item in record['before'])
assert record['before_wrapper']['returncode'] == 1
assert all(item['returncode'] == 0 for item in record['after'])
assert all(item['failures'] == '0' for item in record['ctest'].values())
assert 'Empty CONFIG linear_mna installed check passed' in (root / 'ctest-Release-detailed.log').read_text(errors='replace')
assert 'Empty CONFIG mna_power_wave_s installed check passed' in (root / 'ctest-Release-detailed.log').read_text(errors='replace')
(root / 'verification.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps({'verification': str(root / 'verification.json'), 'ctest': record['ctest']}))
