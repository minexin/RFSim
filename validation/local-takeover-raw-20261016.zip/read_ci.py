"""Read the exact commit's push CI; save raw public run/jobs snapshots."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
commit = sys.argv[1]
assert len(commit) == 40 and all(c in '0123456789abcdef' for c in commit)
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
output = ROOT/'ci-snapshots'/stamp
output.mkdir(parents=True, exist_ok=False)

def fetch(endpoint, name):
    data = subprocess.check_output(['gh','api',endpoint], cwd=REPO, env=dict(os.environ))
    (output/name).write_bytes(data)
    return json.loads(data)

runs = fetch('repos/minexin/RFSim/actions/runs?head_sha='+commit+'&event=push&per_page=100','runs.json')
matching = [r for r in runs['workflow_runs'] if r['head_sha']==commit and r['path']=='.github/workflows/build.yml']
if not matching:
    print(json.dumps(dict(status='no_run_yet',head_sha=commit,output=str(output))))
    raise SystemExit(0)
latest = max(matching,key=lambda r:(r['run_attempt'],r['id']))
run = fetch('repos/minexin/RFSim/actions/runs/'+str(latest['id']),'run.json')
jobs = fetch('repos/minexin/RFSim/actions/runs/'+str(latest['id'])+'/jobs?per_page=100','jobs.json')
assert run['head_sha'] == commit
assert jobs['total_count'] == len(jobs['jobs']), 'Pagination would be required'
for j in jobs['jobs']:
    assert j['run_id'] == run['id'] and j['head_sha'] == commit
summary = dict(head_sha=commit, run_id=run['id'], url=run['html_url'], status=run['status'],
    conclusion=run['conclusion'], jobs=len(jobs['jobs']),
    successful_jobs=sum(j['conclusion']=='success' for j in jobs['jobs']),
    failed_jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'],url=j['html_url'])
        for j in jobs['jobs'] if j['status']=='completed' and j['conclusion']!='success'],
    pending=[j['name'] for j in jobs['jobs'] if j['status']!='completed'],
    observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),output=str(output),
    raw_sha256={n:hashlib.sha256((output/n).read_bytes()).hexdigest() for n in ('run.json','jobs.json')})
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary),flush=True)
